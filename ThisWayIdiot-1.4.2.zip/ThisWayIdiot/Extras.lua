-- This Way Idiot: quest-item button + map pins (our own code; map placement via HereBeDragons, BSD).
-- Core calls TWI_OnStep(current, nearby) after every refresh.
local ADDON = ...
local WHITE = "Interface\\Buttons\\WHITE8X8"
local ACC = { 0.18, 0.95, 0.6 }
local DB

-- ---------- quest-item button (secure: a real click uses the item; attributes only change out of combat) ----------
local btn, pending, pendingDirty, shownItem
local function questItemFor(cur)
  if not cur or not cur.step then return nil end
  local s = cur.step
  for _, q in ipairs(s.q or {}) do
    local id = q[1]
    local li = GetQuestLogIndexByID and GetQuestLogIndexByID(id)
    if li and li > 0 and GetQuestLogSpecialItemInfo then
      local ok, link = pcall(GetQuestLogSpecialItemInfo, li)
      if ok and link then
        local item = tonumber(tostring(link):match("item:(%d+)"))
        if item then return item end
      end
    end
    -- quests started by an item in your bags
    if s.t == "A" and q[8] and q[8] > 0 and GetItemCount and GetItemCount(q[8]) > 0 then return q[8] end
  end
end

local function applyItem(item)
  if InCombatLockdown() then pendingDirty = true; return end
  pendingDirty = false
  shownItem = item
  if item then
    btn:SetAttribute("type", "item"); btn:SetAttribute("item", "item:" .. item)
    local icon = GetItemIcon and GetItemIcon(item)
    btn.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    btn.name = GetItemInfo(item) or "Quest item"
    btn:Show()
  else
    btn:SetAttribute("type", nil); btn:SetAttribute("item", nil)
    btn:Hide()
  end
end

local function buildButton()
  btn = CreateFrame("Button", "TWIQuestItemButton", UIParent, "SecureActionButtonTemplate")
  btn:SetSize(40, 40); btn:RegisterForClicks("AnyUp", "AnyDown")
  btn:SetFrameStrata("MEDIUM")
  local bg = btn:CreateTexture(nil, "BACKGROUND"); bg:SetTexture(WHITE); bg:SetAllPoints(); bg:SetVertexColor(0.045, 0.05, 0.058, 0.93)
  btn.icon = btn:CreateTexture(nil, "ARTWORK"); btn.icon:SetPoint("TOPLEFT", 3, -3); btn.icon:SetPoint("BOTTOMRIGHT", -3, 3)
  btn.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
  for _, e in ipairs({ { "TOPLEFT", "TOPRIGHT", nil, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", nil, 1 }, { "TOPLEFT", "BOTTOMLEFT", 1, nil }, { "TOPRIGHT", "BOTTOMRIGHT", 1, nil } }) do
    local t = btn:CreateTexture(nil, "BORDER"); t:SetTexture(WHITE); t:SetVertexColor(ACC[1], ACC[2], ACC[3], 0.5)
    t:SetPoint(e[1]); t:SetPoint(e[2]); if e[3] then t:SetWidth(e[3]) end; if e[4] then t:SetHeight(e[4]) end
  end
  btn.cd = CreateFrame("Cooldown", nil, btn, "CooldownFrameTemplate"); btn.cd:SetAllPoints(btn.icon)
  btn.hint = btn:CreateFontString(nil, "OVERLAY"); btn.hint:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
  btn.hint:SetPoint("TOP", btn, "BOTTOM", 0, -3); btn.hint:SetTextColor(0.6, 0.63, 0.66)
  btn:SetHighlightTexture(WHITE); local hl = btn:GetHighlightTexture(); if hl then hl:SetVertexColor(1, 1, 1, 0.12) end
  btn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    if shownItem then GameTooltip:SetItemByID(shownItem) end
    GameTooltip:AddLine("Click to use. Drag with Alt to move.", ACC[1], ACC[2], ACC[3]); GameTooltip:Show()
  end)
  btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
  btn:SetMovable(true); btn:RegisterForDrag("LeftButton")
  btn:SetScript("OnDragStart", function(self) if IsAltKeyDown() and not InCombatLockdown() then self:StartMoving() end end)
  btn:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p, _, rp, x, y = self:GetPoint(); DB.itemPos = { p, rp, x, y }
  end)
  local sp = DB.itemPos
  if sp then btn:SetPoint(sp[1], UIParent, sp[2], sp[3], sp[4]) else btn:SetPoint("CENTER", UIParent, "CENTER", 0, -170) end
  local tick = 0
  btn:SetScript("OnUpdate", function(self, el)
    tick = tick + el
    if tick < 0.5 then return end
    tick = 0
    if shownItem and GetItemCooldown then
      local st, dur = GetItemCooldown(shownItem)
      if st and dur and dur > 1.5 then self.cd:SetCooldown(st, dur) end
    end
    self.hint:SetText(InCombatLockdown() and pendingDirty and "updates after combat" or "")
  end)
  btn:Hide()
end

-- ---------- map pins: one big pin on the current target, small ones on the other nearby objectives ----------
local HBD, Pins
local worldPins, miniPins = {}, {}
local function pinFrame(big, mini)
  local f = CreateFrame("Frame", nil, mini and Minimap or UIParent)
  local sz = big and (mini and 16 or 20) or (mini and 9 or 11)
  f:SetSize(sz, sz)
  local ring = f:CreateTexture(nil, "OVERLAY"); ring:SetAllPoints()
  ring:SetTexture("Interface\\AddOns\\" .. ADDON .. "\\ring")
  ring:SetVertexColor(ACC[1], ACC[2], ACC[3], big and 1 or 0.75)
  local dot = f:CreateTexture(nil, "ARTWORK"); dot:SetTexture(WHITE); dot:SetSize(sz * 0.35, sz * 0.35); dot:SetPoint("CENTER")
  dot:SetVertexColor(1, 1, 1, big and 0.95 or 0.6)
  f:EnableMouse(true)
  f:SetScript("OnEnter", function(self)
    if not self.label then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:AddLine(self.label, 1, 1, 1)
    if self.sub then GameTooltip:AddLine(self.sub, 0.7, 0.72, 0.74, true) end
    GameTooltip:Show()
  end)
  f:SetScript("OnLeave", function() GameTooltip:Hide() end)
  return f
end

local function setPins(list)
  if not Pins then return end
  Pins:RemoveAllWorldMapIcons("TWI"); Pins:RemoveAllMinimapIcons("TWI")
  if DB.pins == false then return end
  for i, w in ipairs(list) do
    local s = w.step
    if s.m and s.x and s.y then
      worldPins[i] = worldPins[i] or pinFrame(i == 1, false)
      miniPins[i] = miniPins[i] or pinFrame(i == 1, true)
      for _, f in ipairs({ worldPins[i], miniPins[i] }) do f.label = w.label; f.sub = s.i end
      -- our steps store north/west like UnitPosition's first two values; HereBeDragons wants (west, north)
      Pins:AddWorldMapIconWorld("TWI", worldPins[i], s.m, s.y, s.x, 3)
      Pins:AddMinimapIconWorld("TWI", miniPins[i], s.m, s.y, s.x, i == 1)
    end
  end
end

function TWI_OnStep(cur, nearby, labelOf)
  if not btn then return end
  local item = questItemFor(cur)
  if item ~= shownItem or pendingDirty then pending = item; applyItem(item) end
  local list = {}
  if cur and cur.step and cur.step.m then list[1] = { step = cur.step, label = labelOf and labelOf(cur.step) or cur.step.w } end
  for _, w in ipairs(nearby or {}) do
    if #list >= 5 then break end
    if w.step ~= (cur and cur.step) then list[#list + 1] = { step = w.step, label = labelOf and labelOf(w.step) or w.step.w } end
  end
  setPins(list)
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED"); f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:SetScript("OnEvent", function(_, e, arg)
  if e == "ADDON_LOADED" and arg == ADDON then
    ThisWayIdiotDB = ThisWayIdiotDB or {}; DB = ThisWayIdiotDB
    if LibStub then
      HBD = LibStub("HereBeDragons-2.0", true); Pins = LibStub("HereBeDragons-Pins-2.0", true)
    end
    buildButton()
  elseif e == "PLAYER_REGEN_ENABLED" then
    if pendingDirty and btn then applyItem(pending) end
  end
end)
