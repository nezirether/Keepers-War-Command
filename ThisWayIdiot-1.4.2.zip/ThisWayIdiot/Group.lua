-- This Way Idiot: group finder (our own code).
-- When the route reaches an elite quest, or a dungeon fits your level, a small strip under the guide
-- shows it with: Post (one line to LookingForGroup, on your click), Finder (opens Blizzard's Group
-- Finder), matching LFG posts from chat with a Whisper button, and guildmates who need the same thing
-- with an Invite button. Nothing is sent without a click; chat is only read.
local ADDON = ...
local DB, CHAR
local PREFIX = "TWI_G"
local WHITE = "Interface\\Buttons\\WHITE8X8"
local FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local ACC = { 0.18, 0.95, 0.6 }
local POST_COOLDOWN = 30
local MATCH_TTL = 300
local MAX_ROWS = 3

-- Horde-reachable dungeons, level window, and the words people use for them in chat
local DUNGEONS = {
  { key = "rfc", name = "Ragefire Chasm", lo = 13, hi = 18, words = { "rfc", "ragefire" } },
  { key = "wc", name = "Wailing Caverns", lo = 17, hi = 24, words = { "wc", "wailing" } },
  { key = "sfk", name = "Shadowfang Keep", lo = 22, hi = 30, words = { "sfk", "shadowfang" } },
  { key = "bfd", name = "Blackfathom Deeps", lo = 24, hi = 32, words = { "bfd", "blackfathom" } },
  { key = "rfk", name = "Razorfen Kraul", lo = 29, hi = 38, words = { "rfk", "kraul" } },
  { key = "gnomer", name = "Gnomeregan", lo = 29, hi = 38, words = { "gnomer", "gnomeregan" } },
  { key = "smgy", name = "SM Graveyard", lo = 28, hi = 38, words = { "gy", "graveyard", "sm" } },
  { key = "smlib", name = "SM Library", lo = 29, hi = 39, words = { "lib", "library", "sm" } },
  { key = "smarm", name = "SM Armory", lo = 32, hi = 42, words = { "arm", "armory", "armoury", "sm" } },
  { key = "smcath", name = "SM Cathedral", lo = 35, hi = 45, words = { "cath", "cathedral", "sm" } },
  { key = "rfd", name = "Razorfen Downs", lo = 37, hi = 46, words = { "rfd", "downs" } },
  { key = "ulda", name = "Uldaman", lo = 41, hi = 51, words = { "ulda", "uldaman", "uld" } },
  { key = "zf", name = "Zul'Farrak", lo = 44, hi = 54, words = { "zf", "farrak" } },
  { key = "mara", name = "Maraudon", lo = 46, hi = 55, words = { "mara", "maraudon" } },
  { key = "st", name = "Sunken Temple", lo = 50, hi = 60, words = { "st", "sunken", "temple" } },
  { key = "brd", name = "Blackrock Depths", lo = 52, hi = 60, words = { "brd" } },
  { key = "dm", name = "Dire Maul", lo = 55, hi = 60, words = { "dm", "dire maul", "dme", "dmw", "dmn" } },
  { key = "lbrs", name = "Lower Blackrock Spire", lo = 55, hi = 60, words = { "lbrs" } },
  { key = "strat", name = "Stratholme", lo = 58, hi = 60, words = { "strat", "stratholme" } },
  { key = "scholo", name = "Scholomance", lo = 58, hi = 60, words = { "scholo", "scholomance" } },
}
local LFG_WORDS = { "lfg", "lfm", "lf%dm", "lf", "need", "looking", "group", "heal", "tank", "dps" }
local ROLE = { PRIEST = "heals", DRUID = "heals", SHAMAN = "heals", PALADIN = "heals", WARRIOR = "tank" }

local target         -- { key, label, kind = "quest"|"dungeon", words = {...} }
local matches = {}   -- chat posts that match the target
local mates = {}     -- guildmates who need the same target: name -> { level, at }
local lastPost = 0

local function now() return GetTime() end
local function inGroup()
  if IsInGroup then return IsInGroup() end
  return (GetNumPartyMembers and GetNumPartyMembers() or 0) > 0
end
local function lower(s) return string.lower(s or "") end
local function hasWord(msg, w)
  if #w <= 3 then return string.find(msg, "%f[%w]" .. w .. "%f[%W]") ~= nil end
  return string.find(msg, w, 1, true) ~= nil
end
local function short(name) return name and (string.match(name, "^([^-]+)") or name) or "?" end

-- ---------- what needs a group right now ----------
local function questTarget(step)
  if not step or not step.q then return nil end
  for _, q in ipairs(step.q) do
    if q[4] and step.t ~= "T" then        -- elite quest, still to do
      local name = q[2] or ""
      local words = { lower(name) }
      -- the first long word of the name is often how people post it ("Vorrel", "Prison")
      local first = string.match(lower(name), "(%a%a%a%a%a+)")
      if first then words[#words + 1] = first end
      return { key = "q" .. q[1], label = name, kind = "quest", words = words }
    end
  end
end

local function dungeonTarget()
  if DB.lfgDungeons == false then return nil end
  local lvl = UnitLevel("player")
  for _, d in ipairs(DUNGEONS) do
    if lvl >= d.lo + 1 and lvl <= d.hi - 3 and not (CHAR.lfgMute and CHAR.lfgMute["d" .. d.key]) then
      return { key = "d" .. d.key, label = d.name, kind = "dungeon", words = d.words }
    end
  end
end

local function pickTarget(cur, nearby)
  if cur and cur.step then
    local t = questTarget(cur.step)
    if t and not (CHAR.lfgMute and CHAR.lfgMute[t.key]) then return t end
  end
  for _, w in ipairs(nearby or {}) do
    local t = questTarget(w.step)
    if t and not (CHAR.lfgMute and CHAR.lfgMute[t.key]) then return t end
  end
  return dungeonTarget()
end

-- ---------- the strip ----------
local strip
local function txt(parent, size, r, g, b)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  fs:SetFont(FONT, size, "")
  fs:SetTextColor(r, g, b)
  fs:SetJustifyH("LEFT")
  fs:SetWordWrap(false)
  return fs
end
local function fill(f, r, g, b, a)
  local t = f:CreateTexture(nil, "BACKGROUND"); t:SetTexture(WHITE); t:SetAllPoints(); t:SetVertexColor(r, g, b, a); return t
end
local function flat(parent, label, w, tip, onClick)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w, 18)
  b.bg = fill(b, 1, 1, 1, 0.06)
  b.fs = txt(b, 10, 0.85, 0.88, 0.92); b.fs:SetPoint("CENTER"); b.fs:SetJustifyH("CENTER"); b.fs:SetText(label)
  b:SetScript("OnEnter", function(self)
    self.bg:SetVertexColor(ACC[1], ACC[2], ACC[3], 0.22)
    if tip then GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(tip, 1, 1, 1, 1, true); GameTooltip:Show() end
  end)
  b:SetScript("OnLeave", function(self) self.bg:SetVertexColor(1, 1, 1, 0.06); GameTooltip:Hide() end)
  b:SetScript("OnClick", onClick)
  return b
end

local function classInfo()
  local cname, cfile = UnitClass("player")
  return cname or "", cfile or ""
end

local function postText()
  local cname, cfile = classInfo()
  local role = ROLE[cfile]
  return "LFG " .. target.label .. (target.kind == "quest" and " (elite quest)" or "") .. " - " .. UnitLevel("player") .. " " .. cname .. (role and (" (" .. role .. ")") or "")
end

local function lfgChannel()
  for _, n in ipairs({ "LookingForGroup", "World" }) do
    local id = GetChannelName(n)
    if id and id > 0 then return id, n end
  end
end

local function post()
  if not target then return end
  if now() - lastPost < POST_COOLDOWN then
    print("|cff33ff99This Way Idiot:|r wait " .. math.ceil(POST_COOLDOWN - (now() - lastPost)) .. "s before posting again.")
    return
  end
  local id, name = lfgChannel()
  if not id then
    print("|cff33ff99This Way Idiot:|r join LookingForGroup first (be in a city, or type /join LookingForGroup).")
    return
  end
  SendChatMessage(postText(), "CHANNEL", nil, id)
  lastPost = now()
  print("|cff33ff99This Way Idiot:|r posted in " .. name .. ".")
end

local function openFinder()
  local ok = false
  for _, fn in ipairs({ "ToggleLFGParentFrame", "LFGParentFrame_Toggle", "PVEFrame_ToggleFrame", "ToggleLFDParentFrame" }) do
    if _G[fn] then ok = pcall(_G[fn]); if ok then break end end
  end
  if not ok and LFGParentFrame and ShowUIPanel then ok = pcall(ShowUIPanel, LFGParentFrame) end
  if not ok then print("|cff33ff99This Way Idiot:|r open the Group Finder from the micro menu (the eye icon).") end
end

local function whisper(who)
  local cname = classInfo()
  SendChatMessage("Hi! I can join for " .. target.label .. " (" .. UnitLevel("player") .. " " .. cname .. ").", "WHISPER", nil, who)
end

local function invite(who)
  if C_PartyInfo and C_PartyInfo.InviteUnit then C_PartyInfo.InviteUnit(who)
  elseif InviteUnit then InviteUnit(who) end
end

local function build()
  strip = CreateFrame("Frame", "ThisWayIdiotGroupStrip", UIParent)
  strip:SetSize(340, 30)
  strip:SetFrameStrata("MEDIUM")
  fill(strip, 0.045, 0.05, 0.058, 0.93)
  local edge = strip:CreateTexture(nil, "BORDER"); edge:SetTexture(WHITE); edge:SetVertexColor(ACC[1], ACC[2], ACC[3], 0.55)
  edge:SetPoint("TOPLEFT"); edge:SetPoint("BOTTOMLEFT"); edge:SetWidth(2)
  strip.kind = txt(strip, 9, ACC[1], ACC[2], ACC[3]); strip.kind:SetPoint("TOPLEFT", 10, -8)
  strip.label = txt(strip, 12, 1, 1, 1); strip.label:SetPoint("LEFT", strip.kind, "RIGHT", 6, 0)
  strip.x = flat(strip, "×", 18, "Not now. Hides this until the next group quest.", function()
    if target then CHAR.lfgMute = CHAR.lfgMute or {}; CHAR.lfgMute[target.key] = true end
    TWI_GroupRefresh(true)
  end)
  strip.x:SetPoint("TOPRIGHT", -5, -5)
  strip.finder = flat(strip, "Finder", 46, "Open Blizzard's Group Finder.", openFinder)
  strip.finder:SetPoint("RIGHT", strip.x, "LEFT", -4, 0)
  strip.post = flat(strip, "Post", 38, "Post one line in LookingForGroup.", post)
  strip.post:SetPoint("RIGHT", strip.finder, "LEFT", -4, 0)
  strip.label:SetPoint("RIGHT", strip.post, "LEFT", -6, 0)
  strip.rows = {}
  for i = 1, MAX_ROWS do
    local r = CreateFrame("Frame", nil, strip)
    r:SetHeight(18)
    r:SetPoint("TOPLEFT", 10, -26 - (i - 1) * 18)
    r:SetPoint("RIGHT", strip, "RIGHT", -5, 0)
    r.btn = flat(r, "Whisper", 52, nil, function(self) local who = self:GetParent().who; if who then if self:GetParent().mate then invite(who) else whisper(who) end end end)
    r.btn:SetPoint("RIGHT", 0, 0)
    r.fs = txt(r, 10, 0.62, 0.66, 0.7); r.fs:SetPoint("LEFT", 0, 0); r.fs:SetPoint("RIGHT", r.btn, "LEFT", -6, 0)
    strip.rows[i] = r
  end
  strip:Hide()
end

local function place()
  local main = _G.ThisWayIdiotFrame
  if not main then return false end
  strip:ClearAllPoints()
  strip:SetPoint("TOPLEFT", main, "BOTTOMLEFT", 0, -4)
  strip:SetPoint("TOPRIGHT", main, "BOTTOMRIGHT", 0, -4)
  strip:SetScale(main:GetScale())
  return main:IsShown()
end

function TWI_GroupRefresh(force)
  if not strip then return end
  local show = DB.lfg ~= false and target and not inGroup() and place()
  if not show then strip:Hide(); return end
  strip.kind:SetText(target.kind == "quest" and "GROUP QUEST" or "DUNGEON")
  strip.label:SetText(target.label)
  -- rows: guildmates first, then chat posts
  local rows = {}
  local t = now()
  for name, m in pairs(mates) do
    if m.key == target.key and t - m.at < 180 then rows[#rows + 1] = { who = name, mate = true, text = "|cffffd100" .. short(name) .. "|r (" .. m.level .. ") is on it too · guild" } end
  end
  for i = #matches, 1, -1 do
    local m = matches[i]
    if t - m.at > MATCH_TTL then table.remove(matches, i)
    elseif m.key == target.key then rows[#rows + 1] = { who = m.who, text = "|cffd8dce2" .. short(m.who) .. ":|r " .. m.msg } end
  end
  local n = math.min(#rows, MAX_ROWS)
  for i, r in ipairs(strip.rows) do
    local row = rows[i]
    if row and i <= n then
      r.who, r.mate = row.who, row.mate
      r.fs:SetText(row.text)
      r.btn.fs:SetText(row.mate and "Invite" or "Whisper")
      r:Show()
    else
      r.who = nil
      r:Hide()
    end
  end
  if n == 0 then
    local r = strip.rows[1]
    r.who = nil
    r.fs:SetText("No posts yet. Post looks for people; matching LFG posts show up here.")
    r.btn:Hide(); r:Show()
    n = 1
  else
    for _, r in ipairs(strip.rows) do r.btn:Show() end
  end
  strip:SetHeight(28 + n * 18 + 4)
  strip:Show()
end

-- ---------- chat + guild ----------
local function onChannel(msg, author, channelName)
  if not target or not msg or short(author) == UnitName("player") then return end
  local ch = lower(channelName)
  if not (string.find(ch, "lookingforgroup", 1, true) or string.find(ch, "world", 1, true) or string.find(ch, "general", 1, true) or string.find(ch, "lfg", 1, true)) then return end
  local m = lower(msg)
  local lfg = false
  for _, w in ipairs(LFG_WORDS) do if string.find(m, "%f[%w]" .. w .. "%f[%W]") then lfg = true; break end end
  if not lfg then return end
  local hit = false
  for _, w in ipairs(target.words) do if hasWord(m, w) then hit = true; break end end
  if not hit then return end
  for i = #matches, 1, -1 do if matches[i].who == author then table.remove(matches, i) end end
  matches[#matches + 1] = { who = author, msg = msg, at = now(), key = target.key }
  while #matches > 8 do table.remove(matches, 1) end
  TWI_GroupRefresh()
end

local lastShare, sharedKey = 0, nil
local function share(force)
  if not IsInGuild() or not target or DB.lfg == false then return end
  if not force and sharedKey == target.key and now() - lastShare < 60 then return end
  sharedKey, lastShare = target.key, now()
  local msg = "GQ~" .. target.key .. "~" .. UnitLevel("player")
  if C_ChatInfo and C_ChatInfo.SendAddonMessage then C_ChatInfo.SendAddonMessage(PREFIX, msg, "GUILD")
  elseif SendAddonMessage then SendAddonMessage(PREFIX, msg, "GUILD") end
end

local function onAddon(msg, sender)
  if short(sender) == UnitName("player") then return end
  local key, level = string.match(msg or "", "^GQ~([^~]+)~(%d+)")
  if key then
    mates[sender] = { key = key, level = tonumber(level), at = now() }
    TWI_GroupRefresh()
  end
end

-- Core calls TWI_OnStep after every refresh; Extras.lua defines it first, we wrap it
local function onStep(cur, nearby)
  local t = pickTarget(cur, nearby)
  local changed = (t and t.key) ~= (target and target.key)
  target = t
  if changed then share(true) else share(false) end
  TWI_GroupRefresh()
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, e, a1, a2, a3, a4, a5, a6, a7, a8, a9)
  if e == "ADDON_LOADED" and a1 == ADDON then
    ThisWayIdiotDB = ThisWayIdiotDB or {}; DB = ThisWayIdiotDB
    ThisWayIdiotChar = ThisWayIdiotChar or {}; CHAR = ThisWayIdiotChar
    build()
    local prev = TWI_OnStep
    TWI_OnStep = function(cur, nearby, labelOf)
      if prev then pcall(prev, cur, nearby, labelOf) end
      onStep(cur, nearby)
    end
    for _, ev in ipairs({ "CHAT_MSG_CHANNEL", "CHAT_MSG_ADDON", "GROUP_ROSTER_UPDATE", "PARTY_MEMBERS_CHANGED" }) do pcall(f.RegisterEvent, f, ev) end
  elseif e == "PLAYER_LOGIN" then
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    elseif RegisterAddonMessagePrefix then RegisterAddonMessagePrefix(PREFIX) end
  elseif e == "CHAT_MSG_CHANNEL" then
    onChannel(a1, a2, a9 or a4)
  elseif e == "CHAT_MSG_ADDON" then
    if a1 == PREFIX then onAddon(a2, a4) end
  else
    TWI_GroupRefresh()
  end
end)

-- /idiot group toggles the strip (Core's slash handler calls this if it exists)
function TWI_GroupToggle()
  DB.lfg = DB.lfg == false
  print("|cff33ff99This Way Idiot:|r group finder " .. (DB.lfg == false and "off" or "on") .. ".")
  TWI_GroupRefresh(true)
end
