# Third-party data

- **QuestieDB / Questie** (github.com/Questie/Questie): WoW Forever quest, NPC and object data. No license file; its maintainers ask that it be treated as all rights reserved and say anyone accepting that risk may use it (Questie#4447). Credited here with thanks; This Way Idiot will remove this data if the Questie maintainers ask.
- **Factoruide** (github.com/brouznouf/factoruide): quest prerequisites, removed-quest list and dungeon entrances from its WoW Forever database (`factoruide_forever.json`, built by `factoruide_export.py`). Code MIT, (c) 2026 Factoruide contributors; quest databases GPL-3.0, compiled from the sources listed in its NOTICE.md.
- **HereBeDragons 2.0 + Pins** by Hendrik "Nevcairiel" Leppkes (BSD license as stated in its .toc; the upstream project ships no separate license file), with **LibStub** (public domain) and **CallbackHandler-1.0** (BSD, the Ace3 authors): bundled unmodified in `ThisWayIdiot/Libs` for world map and minimap pins. All rights to those libraries stay with their authors.

This Way Idiot itself is GPL-3.0 (LICENSE.md). It is free, has no ads, and asks for nothing in game.
