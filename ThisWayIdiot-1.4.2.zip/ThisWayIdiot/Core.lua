-- This Way Idiot: standalone Horde 20-60 leveling guide with its own step window and arrow.
-- Steps (Data.lua, TWI_DATA) are routed shortest-path and grouped by NPC. Progress is read from the game, so
-- steps tick themselves off: quests from the quest log, hearth from your bind location, flight path when the
-- flight map opens, restock when you close a vendor.
-- /idiot = show/hide   /idiot zones = pick a zone   /idiot skip   /idiot arrow   /idiot reset

local ADDON = ...
local DATA = TWI_DATA
local PI2 = math.pi * 2
local atan2, sqrt, floor, abs = math.atan2, math.sqrt, math.floor, math.abs

local DB, CHAR
local main, arrow, legList
local lines = {}
local current
local SHOW_LINES = 5

-- ---------- game state helpers ----------
local function isCompleted(id)
  if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then return C_QuestLog.IsQuestFlaggedCompleted(id) end
  return IsQuestFlaggedCompleted and IsQuestFlaggedCompleted(id) or false
end

local function logIndex(id)
  if C_QuestLog and C_QuestLog.GetLogIndexForQuestID then
    local i = C_QuestLog.GetLogIndexForQuestID(id)
    if i and i > 0 then return i end
  end
  if GetQuestLogIndexByID then
    local i = GetQuestLogIndexByID(id)
    if i and i > 0 then return i end
  end
end

local function objectivesDone(id)
  local i = logIndex(id)
  if not i then return false end
  if C_QuestLog and C_QuestLog.IsComplete then
    local ok, res = pcall(C_QuestLog.IsComplete, id)
    if ok and res ~= nil then return res and true or false end
  end
  if GetQuestLogTitle then
    local c = select(6, GetQuestLogTitle(i))
    return c == 1 or c == true
  end
  return false
end

-- one objective of a quest (by mob/item/object name) finished?
local function objectiveDone(id, label)
  if not label or label == "" then return objectivesDone(id) end
  local want = label:lower():gsub("s$", "")
  if C_QuestLog and C_QuestLog.GetQuestObjectives then
    local ok, list = pcall(C_QuestLog.GetQuestObjectives, id)
    if ok and type(list) == "table" and #list > 0 then
      for _, o in ipairs(list) do
        if o.text and o.text:lower():find(want, 1, true) then return o.finished and true or false end
      end
    end
  end
  local i = logIndex(id)
  if i and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
    local n = GetNumQuestLeaderBoards(i) or 0
    for j = 1, n do
      local text, _, finished = GetQuestLogLeaderBoard(j, i)
      if text and text:lower():find(want, 1, true) then return finished and true or false end
    end
  end
  return objectivesDone(id)
end

local function questLogCount()
  local n = GetNumQuestLogEntries and select(2, GetNumQuestLogEntries())
  return n or 0
end

-- vendor water tiers (level to use it, item ID, name); Astra 11/12: Melon Juice at 15-24
local WATER = { { 45, 8766, "Morning Glory Dew" }, { 35, 1645, "Moonberry Juice" }, { 25, 1708, "Sweet Nectar" },
  { 15, 1205, "Melon Juice" }, { 5, 1179, "Ice Cold Milk" }, { 1, 159, "Refreshing Spring Water" } }
local WATER_TARGET = 20
local function water()
  local lvl = UnitLevel("player")
  for _, w in ipairs(WATER) do
    if lvl >= w[1] then
      local have = GetItemCount and GetItemCount(w[2]) or 0
      return w[3], have, math.max(0, WATER_TARGET - have)
    end
  end
end

-- ---------- step state ----------
-- step: t = G go to hub | F flight path | H set hearth | V vendor/restock | A accept | C do objectives | T turn in
--       w = who/where, i = info, m/x/y = server coords, q = {{id, name, req, elite, {pre}}, ...}
local function key(leg, idx)
  local s = DATA[leg] and DATA[leg].s[idx]
  return (s and s.k) or (leg .. ":" .. idx)
end

-- quests this far below you give almost no XP ("gray"); Classic rule of thumb, or the client's own range
local function grayBelow(lvl)
  if GetQuestGreenRange then
    local ok, r = pcall(GetQuestGreenRange)
    if ok and type(r) == "number" and r > 0 then return r end
  end
  if lvl <= 5 then return 5 elseif lvl <= 39 then return 5 + floor(lvl / 10) elseif lvl <= 59 then return 1 + floor(lvl / 5) end
  return 9
end
local function isGray(q)
  local ql = q[7] or 0
  if ql <= 0 then return false end
  local lvl = UnitLevel("player")
  return ql < lvl - grayBelow(lvl)
end

local function questState(t, q, label)
  local id = q[1]
  if isCompleted(id) then return "done" end
  local active = logIndex(id) ~= nil
  if t == "A" then
    if active then return "done" end
    -- you talked to this NPC and they didn't offer it: trust the game, not the data, until you level or turn in
    local na = CHAR.na and CHAR.na[id]
    if na and na >= UnitLevel("player") then return "blocked", "not offered yet" end
    if isGray(q) then return "blocked", "too low" end
    if (q[8] or 0) > 0 and (not GetItemCount or GetItemCount(q[8]) == 0) then return "blocked", "item not found yet" end
    if (q[3] or 0) > UnitLevel("player") then return "blocked", "level " .. q[3] end
    for _, p in ipairs(q[5] or {}) do if not isCompleted(p) then return "blocked", "earlier quest" end end
    if q[6] and #q[6] > 0 then       -- needs any ONE of these done first
      local ok = false
      for _, p in ipairs(q[6]) do if isCompleted(p) then ok = true; break end end
      if not ok then return "blocked", "earlier quest" end
    end
    return "todo"
  elseif t == "C" then
    if not active then return "blocked", "not picked up" end
    return objectiveDone(id, label) and "done" or "todo"
  else
    if not active then return "blocked", "not picked up" end
    if not objectivesDone(id) then return "blocked", "not finished" end
    return "todo"
  end
end

local function playerPos()
  local a, b, _, inst = UnitPosition("player")
  return a, b, inst          -- server coords: a = north, b = west
end

local function distanceTo(s)
  if not s.m then return nil end
  local px, py, inst = playerPos()
  if not px or inst ~= s.m then return nil end
  local dN, dW = s.x - px, s.y - py
  return sqrt(dN * dN + dW * dW)
end

local function stepState(leg, idx, s)
  local k = key(leg, idx)
  if CHAR.skip[k] then return "skipped" end
  if CHAR.done[k] then return "done" end
  local t = s.t
  if t == "G" then
    return "todo"                       -- ticked by the arrival poll
  elseif t == "F" then
    -- known flight paths are recorded whenever any flight map is open
    local hub = DATA[leg].hub:lower()
    for name in pairs(CHAR.fp or {}) do
      if name:lower():find(hub, 1, true) then return "done" end
    end
    return "todo"
  elseif t == "V" then
    return "todo"                       -- ticked by MERCHANT_CLOSED near the innkeeper (or Skip)
  elseif t == "H" then
    local bind = GetBindLocation and GetBindLocation()
    local hub = DATA[leg].hub
    if bind and (bind:lower():find(hub:lower(), 1, true) or hub:lower():find(bind:lower(), 1, true)) then return "done" end
    return "todo"
  end
  local anyTodo, anyBlocked, why = false, false, nil
  for _, q in ipairs(s.q) do
    local st, r = questState(t, q, t == "C" and s.w or nil)
    if st == "todo" then anyTodo = true elseif st == "blocked" then anyBlocked = true; why = why or r end
  end
  if anyTodo then return "todo" end
  if anyBlocked then
    if t == "A" then   -- some taken, the rest not available yet: nothing to do here for now
      for _, q in ipairs(s.q) do if questState(t, q) == "done" then return "done" end end
    end
    return "blocked", why
  end
  return "done"
end

-- quests you're already carrying come first: the nearest step (objective or turn-in) of a quest in your log,
-- from any zone section, as long as it's in this zone or close by. New pickups only once those are handled.
local NEAR_YARDS = 1800      -- only what counts as "here" for the ALSO HERE list; never a cut-off for what's actionable
local AT_NPC = 60            -- a turn-in wins over field work only when you're standing at that NPC
-- does this zone section have open work (objective or turn-in) for a quest in your log?
local function hasLogWork(leg)
  for idx, s in ipairs(DATA[leg].s) do
    if (s.t == "C" or s.t == "T") and stepState(leg, idx, s) == "todo" then return true end
  end
  return false
end
TWI_HasLogWork = hasLogWork

-- all open work for quests in your log. onlyLeg: you picked a zone, only its quests count (wherever their objectives are)
local function openWork(onlyLeg)
  local out = {}
  for leg, L in ipairs(DATA) do
    if not onlyLeg or leg == onlyLeg then
      for idx, s in ipairs(L.s) do
        if (s.t == "C" or s.t == "T") and stepState(leg, idx, s) == "todo" then
          out[#out + 1] = { leg = leg, idx = idx, step = s, d = distanceTo(s) }
        end
      end
    end
  end
  return out
end

-- the next thing to do among quests you carry: field objectives first (any distance on your continent), a turn-in only
-- when you're at that NPC or the field work is done. Sticky: keeps its pick unless another is clearly (20%) closer,
-- so walking between two camps doesn't make the arrow flip.
local function activeWork(onlyLeg)
  local here = GetRealZoneText and GetRealZoneText() or ""
  local work = openWork(onlyLeg)
  local bestC, bestT, noLoc, keep
  for _, w in ipairs(work) do
    local k = key(w.leg, w.idx)
    if w.d then
      if w.step.t == "C" then
        if not bestC or w.d < bestC.d then bestC = w end
      elseif not bestT or w.d < bestT.d then bestT = w end
      if k == CHAR.awKey then keep = w end
    elseif w.step.t == "C" and not noLoc and (onlyLeg or DATA[w.leg].z == here) then noLoc = w end
  end
  local pick
  if bestT and bestT.d < AT_NPC then pick = bestT
  elseif bestC then
    pick = bestC
    if keep and keep.step.t == "C" and keep ~= bestC and bestC.d >= keep.d * 0.8 then pick = keep end
  else pick = bestT or noLoc end
  CHAR.awKey = pick and key(pick.leg, pick.idx) or nil
  return pick
end

-- open objectives / turn-ins you can see from here (known distance, under NEAR_YARDS), nearest first
local function activeList(onlyLeg)
  local out = {}
  for _, w in ipairs(openWork(onlyLeg)) do
    if w.d and w.d < NEAR_YARDS then out[#out + 1] = w end
  end
  table.sort(out, function(a, b) return a.d < b.d end)
  return out
end
TWI_ActiveList = activeList

-- ---------- zone plan: the fastest way through the zone you're in ----------
-- 1. Hub sweep: every pickup and turn-in within HUB_YARDS, nearest first (turn-ins there unlock follow-ups,
--    which then show up as new pickups in the same stop).
-- 2. Field: nearest objective or out-of-town quest giver in this zone, sticky so the arrow doesn't flip.
-- 3. Turn-ins left in this zone, nearest first.
local HUB_YARDS = 450

-- the zone section for where you're standing: your current section if it's here, else the lowest one here with work
local function zoneLeg()
  local here = GetRealZoneText and GetRealZoneText() or ""
  if here == "" then return nil end
  if CHAR.auto == false then
    local L = DATA[CHAR.leg]
    return (L and L.z == here) and CHAR.leg or nil
  end
  local best
  for leg, L in ipairs(DATA) do
    if L.z == here then
      local hasTodo = false
      for idx, s in ipairs(L.s) do
        if (s.t == "A" or s.t == "C" or s.t == "T") and stepState(leg, idx, s) == "todo" then hasTodo = true; break end
      end
      if hasTodo then
        if leg == CHAR.leg then return leg end
        if not best then best = leg end
      end
    end
  end
  return best
end

local function zoneWork(zl)
  local hub, field, keep, turnin
  for idx, s in ipairs(DATA[zl].s) do
    if (s.t == "A" or s.t == "C" or s.t == "T") and stepState(zl, idx, s) == "todo" then
      local d = distanceTo(s)
      if d then
        local w = { leg = zl, idx = idx, step = s, d = d }
        if (s.t == "A" or s.t == "T") and d <= HUB_YARDS then
          if not hub or d < hub.d then hub = w end
        elseif s.t == "T" then
          if not turnin or d < turnin.d then turnin = w end
        else
          if not field or d < field.d then field = w end
          if key(zl, idx) == CHAR.awKey then keep = w end
        end
      end
    end
  end
  local zone = DATA[zl].z
  if hub then
    hub.why = hub.step.t == "A" and ("pick up everything here before heading out (" .. zone .. ")") or "turn in while you're here"
    return hub
  end
  if field then
    if keep and keep ~= field and field.d >= keep.d * 0.8 then field = keep end
    CHAR.awKey = key(field.leg, field.idx)
    field.why = field.step.t == "A" and ("quest giver on your way through " .. zone) or ("nearest objective in " .. zone)
    return field
  end
  if turnin then turnin.why = zone .. " field work done: turn in"; return turnin end
end

local findCurrent
function TWI_FindCurrent() return findCurrent() end
findCurrent = function()
  local leg = CHAR.leg
  local L = DATA[leg]
  if not L then return nil end
  -- 1) a step you clicked in the Full guide (CHAR.pin) wins until it's done; a turn-in pin never beats unfinished
  --    field work of the same quest
  local p = CHAR.pin
  local ps = p and DATA[p[1]] and DATA[p[1]].s[p[2]]
  if ps then
    if stepState(p[1], p[2], ps) ~= "todo" then CHAR.pin = nil
    else
      local blocked = false
      if ps.t == "T" then
        for _, w in ipairs(openWork(nil)) do
          if w.step.t == "C" then for _, q in ipairs(ps.q) do if w.step.q[1][1] == q[1] then blocked = true end end end
        end
      end
      if not blocked then return { leg = p[1], idx = p[2], step = ps, why = "you picked this step" } end
    end
  end
  -- 2) the trip to a new zone (CHAR.from = its "Go to" step), only while you carry no quest work for that zone
  local f = CHAR.from
  local fs = f and DATA[f[1]] and DATA[f[1]].s[f[2]]
  if fs and fs.t == "G" and stepState(f[1], f[2], fs) == "todo" and not hasLogWork(f[1]) then
    return { leg = f[1], idx = f[2], step = fs, why = "travel to your new zone" }
  end
  if f and not (fs and fs.t == "G" and stepState(f[1], f[2], fs) == "todo") then CHAR.from = nil end
  -- 3) clear the zone you're standing in: everything at the hub, then the field, then its turn-ins.
  --    Quests carried from other zones wait until this zone is done.
  local zl = zoneLeg()
  if zl then
    local zw = zoneWork(zl)
    if zw then return zw end
  end
  -- 4) quests you carry: nearest field objective first, turn-ins when at the NPC or the field work is done
  local aw = activeWork(CHAR.auto == false and leg or nil)
  if aw then aw.why = aw.step.t == "T" and (aw.d and aw.d < AT_NPC and "you're at this NPC" or "no field work left for your quests") or "nearest objective of a quest you carry"; return aw end
  for idx = 1, #L.s do
    if stepState(leg, idx, L.s[idx]) == "todo" then return { leg = leg, idx = idx, step = L.s[idx] } end
  end
end

-- how many of a zone's quests are already turned in / still open to do
local function legProgress(leg)
  local seen, done, total = {}, 0, 0
  for _, s in ipairs(DATA[leg].s) do
    for _, q in ipairs(s.q or {}) do
      if not seen[q[1]] then
        seen[q[1]] = true; total = total + 1
        if isCompleted(q[1]) then done = done + 1 end
      end
    end
  end
  return done, total
end

local function hasWork(leg)
  for idx, s in ipairs(DATA[leg].s) do
    if s.t ~= "G" and s.t ~= "F" and s.t ~= "H" and s.t ~= "V" and stepState(leg, idx, s) == "todo" then return true end
  end
  return false
end

-- how much worthwhile questing a zone still has for you right now (unique quests you can take, are on, or can finish)
local function legScore(leg)
  local seen, n = {}, 0
  local lvl = UnitLevel("player")
  for _, st in ipairs(DATA[leg].s) do
    for _, q in ipairs(st.q or {}) do
      if not seen[q[1]] then
        seen[q[1]] = true
        if logIndex(q[1]) then n = n + 1.5
        elseif st.t == "A" and questState("A", q) == "todo" then n = n + 1 end
      end
    end
  end
  return n
end

-- the automatic pick: the zone you're in if it's still worth it; otherwise the first zone on the route for your level
-- with enough left to be worth the trip; otherwise whatever has the most. Starting zones only if you're in one.
local START_ZONES = { Durotar = true, Mulgore = true, ["Tirisfal Glades"] = true }
-- quests of this zone section that are sitting in your quest log right now
local function inLog(leg)
  local seen, n = {}, 0
  for _, st in ipairs(DATA[leg].s) do
    for _, q in ipairs(st.q or {}) do
      if not seen[q[1]] then seen[q[1]] = true; if logIndex(q[1]) then n = n + 1 end end
    end
  end
  return n
end

local function bestLeg()
  local lvl = UnitLevel("player")
  local here = GetRealZoneText and GetRealZoneText() or ""
  local best, bestScore = nil, 0
  -- never pull you out of the zone you're standing in while you still carry its quests: the current section first,
  -- then the section of this zone with the most of your quests
  local cur = CHAR.leg and DATA[CHAR.leg]
  if cur and cur.z == here and inLog(CHAR.leg) > 0 and hasWork(CHAR.leg) then return CHAR.leg end
  local most, mostN = nil, 0
  for i, L in ipairs(DATA) do
    if L.z == here and hasWork(i) then local n = inLog(i); if n > mostN then most, mostN = i, n end end
  end
  if most then return most end
  for i, L in ipairs(DATA) do
    if L.z == here and lvl < L.hi + 1 and legScore(i) >= 3 then return i end
  end
  for i, L in ipairs(DATA) do
    if not START_ZONES[L.z] and lvl >= L.lo - 1 and lvl < L.hi then
      local sc = legScore(i)
      if sc >= 5 then return i end
      if sc > bestScore then best, bestScore = i, sc end
    end
  end
  if best then return best end
  for i, L in ipairs(DATA) do
    if not START_ZONES[L.z] and lvl < L.hi and legScore(i) > 0 then return i end
  end
  return CHAR.leg or 1
end

-- quests still worth doing in a zone right now (in your log, or open to pick up)
local function leftIn(leg)
  local seen, n = {}, 0
  for _, st in ipairs(DATA[leg].s) do
    for _, q in ipairs(st.q or {}) do
      if not seen[q[1]] then
        seen[q[1]] = true
        if logIndex(q[1]) or (st.t == "A" and questState("A", q) == "todo") then n = n + 1 end
      end
    end
  end
  return n
end

-- where you go AFTER the current zone: the first other zone on the route that fits your level and has real work,
-- so you always know your next move before this one runs dry
local function nextLeg()
  local lvl = UnitLevel("player")
  local cur = DATA[CHAR.leg]
  local curZ = cur and cur.z
  for i, L in ipairs(DATA) do
    if i ~= CHAR.leg and L.z ~= curZ and not START_ZONES[L.z] and lvl >= L.lo - 2 and lvl < L.hi and legScore(i) >= 3 then return i end
  end
  for i, L in ipairs(DATA) do
    if i > (CHAR.leg or 0) and L.z ~= curZ and not START_ZONES[L.z] and lvl < L.hi and legScore(i) > 0 then return i end
  end
end

TWI_NextLeg = nextLeg; TWI_LeftIn = leftIn

-- pick where to start: the zone you're standing in if it fits your level and has work left,
-- otherwise the first zone for your level that still has work left
local function defaultLeg()
  local lvl = UnitLevel("player")
  local here = GetRealZoneText and GetRealZoneText() or ""
  for i, L in ipairs(DATA) do
    if L.z == here and lvl >= L.lo - 2 and lvl < L.hi and hasWork(i) then return i end
  end
  -- starting zones are race-specific: only suggest one if you're standing in it
  local START = { Durotar = true, Mulgore = true, ["Tirisfal Glades"] = true }
  for i, L in ipairs(DATA) do
    if lvl < L.hi and not START[L.z] and hasWork(i) then return i end
  end
  for i, L in ipairs(DATA) do if lvl < L.hi then return i end end
  return #DATA
end

-- ---------- text ----------
local C_ACC, C_DO, C_TURN, C_TOWN, C_GREY = "|cffffd100", "|cff66ccff", "|cff33ff99", "|cffff9933", "|cff888888"

local function todoNames(t, s)
  local out = {}
  for _, q in ipairs(s.q) do
    if questState(t, q, t == "C" and s.w or nil) == "todo" then out[#out + 1] = q[2] end
  end
  return out
end

local function stepText(s, leg)
  local t = s.t
  if t == "G" then return C_TOWN .. "Go to " .. s.w .. "|r\n   " .. C_GREY .. s.i .. "|r" end
  if t == "F" then
    local hint = next(CHAR.fp or {}) and "" or ("\n   " .. C_GREY .. "Already have it? Open any flight map once and I'll remember all your flight paths.|r")
    return C_TOWN .. "Get the flight path|r from " .. s.w .. hint
  end
  if t == "H" then return C_TOWN .. "Set your hearthstone|r at " .. s.w end
  if t == "V" then
    local wn, have, need = water()
    local buy = (need and need > 0) and ("Buy " .. need .. " " .. wn .. " (you have " .. have .. ")")
      or ("Water is stocked (" .. (have or 0) .. " " .. (wn or "") .. ")")
    return C_TOWN .. "Sell junk|r at " .. s.w .. "\n   " .. C_GREY .. buy .. "|r"
  end
  local names = todoNames(t, s)
  if #names == 0 then for _, q in ipairs(s.q) do names[#names + 1] = q[2] end end
  if t == "A" then
    local head = #names > 1 and (C_ACC .. "Pick up " .. #names .. " quests|r from ") or (C_ACC .. "Accept|r from ")
    return head .. (s.w ~= "" and s.w or "?") .. "\n   " .. C_GREY .. table.concat(names, ", ") .. "|r"
  elseif t == "C" then
    local where = s.w ~= "" and (C_DO .. s.w .. "|r for ") or ""
    local nopos = s.m and "" or "\n   |cffff9933No map spot known: check your quest log.|r"
    return C_DO .. "Do|r " .. where .. names[1] .. (s.i ~= "" and ("\n   " .. C_GREY .. s.i .. "|r") or "") .. nopos
  else
    local head = #names > 1 and (C_TURN .. "Turn in " .. #names .. " quests|r at ") or (C_TURN .. "Turn in|r at ")
    return head .. (s.w ~= "" and s.w or "?") .. "\n   " .. C_GREY .. table.concat(names, ", ") .. "|r"
  end
end

-- ---------- look ----------
local WHITE = "Interface\\Buttons\\WHITE8X8"
local FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local ACCENT = { 0.18, 0.95, 0.6 }
local TYPE = {   -- icon + accent color per step type
  A = { "Interface\\GossipFrame\\AvailableQuestIcon", 1, 0.82, 0.1, "PICK UP" },
  C = { "Interface\\Icons\\Ability_DualWield", 0.4, 0.78, 1, "DO" },
  T = { "Interface\\GossipFrame\\ActiveQuestIcon", 0.25, 1, 0.55, "TURN IN" },
  G = { "Interface\\Icons\\INV_Misc_Map_01", 1, 0.6, 0.25, "TRAVEL" },
  F = { "Interface\\Icons\\Ability_Mount_Wyvern_01", 1, 0.6, 0.25, "FLIGHT PATH" },
  H = { "Interface\\Icons\\INV_Misc_Rune_01", 1, 0.6, 0.25, "HEARTHSTONE" },
  V = { "Interface\\Icons\\INV_Drink_07", 1, 0.6, 0.25, "RESTOCK" },
}

local function font(fs, size, flags) fs:SetFont(FONT, size, flags or ""); return fs end
local function text(parent, size, r, g, b, flags)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  font(fs, size, flags); fs:SetTextColor(r or 1, g or 1, b or 1); fs:SetJustifyH("LEFT")
  return fs
end
local function fill(f, r, g, b, a)
  local t = f:CreateTexture(nil, "BACKGROUND"); t:SetTexture(WHITE); t:SetAllPoints(); t:SetVertexColor(r, g, b, a or 1)
  return t
end
local function border(f, r, g, b, a)
  local function edge(p1, p2, w, h)
    local t = f:CreateTexture(nil, "BORDER"); t:SetTexture(WHITE); t:SetVertexColor(r, g, b, a or 1)
    t:SetPoint(p1); t:SetPoint(p2)
    if w then t:SetWidth(w) end
    if h then t:SetHeight(h) end
  end
  edge("TOPLEFT", "TOPRIGHT", nil, 1); edge("BOTTOMLEFT", "BOTTOMRIGHT", nil, 1)
  edge("TOPLEFT", "BOTTOMLEFT", 1, nil); edge("TOPRIGHT", "BOTTOMRIGHT", 1, nil)
end
local function bar(parent, r, g, b)
  local sb = CreateFrame("StatusBar", nil, parent)
  sb:SetStatusBarTexture(WHITE); sb:SetStatusBarColor(r, g, b); sb:SetMinMaxValues(0, 1); sb:SetHeight(3)
  local bg = sb:CreateTexture(nil, "BACKGROUND"); bg:SetTexture(WHITE); bg:SetAllPoints(); bg:SetVertexColor(1, 1, 1, 0.07)
  return sb
end
local function flatButton(parent, label, w, tip, onClick)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w, 22)
  b.bg = fill(b, 1, 1, 1, 0.06)
  border(b, 1, 1, 1, 0.12)
  b.fs = text(b, 11, 0.85, 0.88, 0.9); b.fs:SetPoint("CENTER"); b.fs:SetJustifyH("CENTER"); b.fs:SetText(label)
  b:SetScript("OnEnter", function(self)
    self.bg:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.18); self.fs:SetTextColor(1, 1, 1)
    if tip then GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(tip, 1, 1, 1, 1, true); GameTooltip:Show() end
  end)
  b:SetScript("OnLeave", function(self) self.bg:SetVertexColor(1, 1, 1, 0.06); self.fs:SetTextColor(0.85, 0.88, 0.9); GameTooltip:Hide() end)
  b:SetScript("OnClick", onClick)
  return b
end

-- live objective lines for a quest in your log: { {text, finished}, ... }
local function questObjectives(id)
  local out = {}
  if C_QuestLog and C_QuestLog.GetQuestObjectives then
    local ok, list = pcall(C_QuestLog.GetQuestObjectives, id)
    if ok and type(list) == "table" then
      for _, o in ipairs(list) do if o.text and o.text ~= "" then out[#out + 1] = { o.text, o.finished } end end
      if #out > 0 then return out end
    end
  end
  local i = logIndex(id)
  if i and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
    for j = 1, (GetNumQuestLeaderBoards(i) or 0) do
      local t, _, done = GetQuestLogLeaderBoard(j, i)
      if t then out[#out + 1] = { t, done } end
    end
  end
  return out
end

-- headline + detail lines for the NOW card
local function stepCard(s)
  local t = s.t
  if t == "G" then return "Go to " .. s.w, { s.i } end
  if t == "F" then
    local d = { "Talk to " .. s.w .. "." }
    if not next(CHAR.fp or {}) then d[2] = "Already have it? Open any flight map once and I'll remember all your flight paths." end
    return "Get the " .. DATA[current.leg].hub .. " flight path", d
  end
  if t == "H" then return "Set your hearthstone here", { "Talk to " .. s.w .. " and make this inn your home." } end
  if t == "V" then
    local wn, have, need = water()
    local d = { "Sell your junk at " .. s.w .. "." }
    if need and need > 0 then d[2] = "Buy " .. need .. " " .. wn .. "  (you have " .. have .. ")"
    else d[2] = "Water's stocked: " .. (have or 0) .. " " .. (wn or "") end
    return "Restock at " .. s.w, d
  end
  local names = todoNames(t, s)
  if #names == 0 then for _, q in ipairs(s.q) do names[#names + 1] = q[2] end end
  if t == "A" then
    local d = {}
    for _, n in ipairs(names) do d[#d + 1] = "|TInterface\\Buttons\\WHITE8X8:5:5:0:1:8:8:0:8:0:8:255:209:0|t  " .. n end
    return (#names > 1 and ("Pick up " .. #names .. " quests from ") or "Accept from ") .. (s.w ~= "" and s.w or "this NPC"), d
  elseif t == "C" then
    local d = {}
    for _, o in ipairs(questObjectives(s.q[1][1])) do
      local mine = s.w == "" or o[1]:lower():find(s.w:lower():gsub("s$", ""), 1, true)
      if mine then d[#d + 1] = (o[2] and "|TInterface\\RaidFrame\\ReadyCheck-Ready:12|t |cff777777" or "|TInterface\\Buttons\\WHITE8X8:5:5:0:1:8:8:0:8:0:8:102:204:255|t  ") .. o[1] .. (o[2] and "|r" or "") end
    end
    if #d == 0 and s.i ~= "" then d[1] = s.i end
    if not s.m then d[#d + 1] = "|cffff9933No map spot known for this one: check your quest log.|r" end
    return names[1] or s.q[1][2], d, (s.w ~= "" and ("Get: " .. s.w) or nil)
  else
    local d = {}
    for _, n in ipairs(names) do d[#d + 1] = "|TInterface\\Buttons\\WHITE8X8:5:5:0:1:8:8:0:8:0:8:51:255:153|t  " .. n end
    return (#names > 1 and ("Turn in " .. #names .. " quests to ") or "Turn in to ") .. (s.w ~= "" and s.w or "this NPC"), d
  end
end

local function shortText(s)
  local t = s.t
  if t == "G" then return "Go to " .. s.w end
  if t == "F" then return "Flight path: " .. s.w end
  if t == "H" then return "Hearth at " .. s.w end
  if t == "V" then return "Restock at " .. s.w end
  local names = todoNames(t, s)
  if t == "C" then return (names[1] or s.q[1][2]) .. (s.w ~= "" and (": " .. s.w) or "") end
  local n = #names
  if t == "A" then return (n > 1 and ("Pick up " .. n .. " from ") or "Pick up from ") .. (s.w ~= "" and s.w or "?") end
  return (n > 1 and ("Turn in " .. n .. " to ") or "Turn in to ") .. (s.w ~= "" and s.w or "?")
end

-- ---------- arrow ----------
local shownAngle, arrived = nil, false
local function arrowMessage(label, msg)
  arrow.tex:Hide(); arrow.shadow:Hide(); arrow.glow:Hide()
  arrow.dist:SetText(""); arrow.label:SetText(label .. "\n|cff8a9399" .. msg .. "|r")
end

-- when you're a ghost, the arrow leads to your body. Corpse spot comes as a map position; it is turned into the same
-- world coords UnitPosition uses (axis order checked against the player's own map/world position, so it can't be swapped)
local NEWLINE = string.char(10)
local function corpseTarget()
  if not (UnitIsGhost and UnitIsGhost("player")) then return nil end
  if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetWorldPosFromMapPos and C_DeathInfo and C_DeathInfo.GetCorpseMapPosition) then return nil end
  local px, py, inst = playerPos()
  if not px then return nil end
  local map = C_Map.GetBestMapForUnit("player")
  for _ = 1, 4 do
    if not map then return nil end
    local cp = C_DeathInfo.GetCorpseMapPosition(map)
    local pp = C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(map, "player")
    if cp and pp then
      local _, cw = C_Map.GetWorldPosFromMapPos(map, cp)
      local _, pw = C_Map.GetWorldPosFromMapPos(map, pp)
      if cw and pw then
        local straight = math.abs(pw.x - px) + math.abs(pw.y - py)
        local swapped = math.abs(pw.y - px) + math.abs(pw.x - py)
        if straight <= swapped then return { m = inst, x = cw.x, y = cw.y } end
        return { m = inst, x = cw.y, y = cw.x }
      end
    end
    local info = C_Map.GetMapInfo and C_Map.GetMapInfo(map)
    map = info and info.parentMapID
  end
end
TWI_CorpseTarget = corpseTarget

local function updateArrow(dt)
  if not arrow then return end
  local body = corpseTarget()
  if not DB.arrow or (not current and not body) then arrow:Hide(); return end
  arrow:Show()
  local s = body or current.step
  local label = body and "Your body" or shortText(s)
  if not s.m then return arrowMessage(label, "No map spot for this step.") end
  if IsInInstance and IsInInstance() then return arrowMessage(label, "In a dungeon: the arrow comes back outside.") end
  local px, py, inst = playerPos()
  local facing = GetPlayerFacing and GetPlayerFacing()
  if not px or facing == nil then return arrowMessage(label, "No position here.") end
  if inst ~= s.m then
    if body then return arrowMessage(label, "Your body is on another map.") end
    if inst == 0 or inst == 1 then
      return arrowMessage(label, "Travel to " .. DATA[current.leg].z .. " (" .. (s.m == 0 and "Eastern Kingdoms" or "Kalimdor") .. ")")
    end
    return arrowMessage(label, "Not on a main continent right now.")
  end
  arrow.tex:Show(); arrow.shadow:Show()
  local dN, dW = s.x - px, s.y - py
  local dist = sqrt(dN * dN + dW * dW)
  local target = (atan2(dW, dN) - facing) % PI2
  -- smooth the turn so the arrow glides instead of jittering
  if not shownAngle then shownAngle = target end
  local diff = (target - shownAngle + math.pi) % PI2 - math.pi
  shownAngle = (shownAngle + diff * math.min(1, (dt or 0.04) * 14)) % PI2
  arrow.tex:SetRotation(shownAngle); arrow.shadow:SetRotation(shownAngle)
  local off = target > math.pi and PI2 - target or target
  local r, g, b
  if dist < 12 then r, g, b = ACCENT[1], ACCENT[2], ACCENT[3]
  elseif off < 0.3 then r, g, b = 0.3, 1, 0.45
  elseif off < 1.2 then r, g, b = 1, 0.82, 0.2
  else r, g, b = 1, 0.35, 0.3 end
  arrow.tex:SetVertexColor(r, g, b)
  arrow.glow:SetVertexColor(r, g, b, 0.35); arrow.glow:Show()
  if dist < 12 then
    arrow.dist:SetText("|cff33ff99You're here|r")
    if not arrived then arrived = true; arrow.pulse:Play() end
  else
    arrived = false
    arrow.dist:SetText(floor(dist) .. " yd")
  end
  arrow.label:SetText(label)
end

-- ---------- main window ----------
local function legName(i)
  local L = DATA[i]
  return L.z .. " (" .. L.hub .. ")"
end
TWI_LegName = legName

-- size the card and the window to what's actually on screen (measured, so nothing overlaps the buttons)
function TWI_Relayout()
  if not main or not main.card then return end
  local card = main.card
  local ch = 34 + card.head:GetStringHeight() + (card.sub:IsShown() and (card.sub:GetStringHeight() + 2) or 0)
    + (card.body:GetText() ~= "" and (card.body:GetStringHeight() + 6) or 0)
  card:SetHeight(math.max(56, ch))
  local top = main:GetTop()
  local last = (main.shownNext or 0) > 0 and main.next[main.shownNext] or card
  local bottom = last:GetBottom()
  if top and bottom then
    main:SetHeight(math.max(140, (top - bottom) + 44))
  else
    local h = 70 + (main.tip:IsShown() and (main.tip:GetStringHeight() + 8) or 0) + card:GetHeight() + 10
      + ((main.shownNext or 0) > 0 and (18 + main.shownNext * 18) or 0) + 40
    main:SetHeight(h)
  end
end

local travelFirst            -- defined with the zone picker; declared here so refresh() sees the local, not a global
local lastKey
local switching = false
local function refresh()
  if not main or not CHAR then return end
  current = findCurrent()
  -- AUTO: when this zone has nothing worth doing for your level, move on by itself and say where
  if CHAR.auto ~= false and not switching then
    local L0 = DATA[CHAR.leg]
    local lvl = UnitLevel("player")
    local here = GetRealZoneText and GetRealZoneText() or ""
    local busyHere = L0.z == here and inLog(CHAR.leg) > 0 and current ~= nil
    local backHere = false   -- standing in a zone whose quests you still carry, but the guide is on another zone
    if L0.z ~= here then
      for i, L in ipairs(DATA) do if L.z == here and inLog(i) > 0 and hasWork(i) then backHere = true; break end end
    end
    if backHere or (not busyHere and (not current or legScore(CHAR.leg) == 0 or lvl >= L0.hi + 1)) then
      local nb = bestLeg()
      if nb ~= CHAR.leg then
        switching = true
        CHAR.leg = nb; CHAR.from = travelFirst(nb)
        current = findCurrent()
        local msg = "Next zone: " .. legName(nb) .. ". Follow the arrow."
        print("|cff33ff99This Way Idiot:|r " .. msg)
        if RaidNotice_AddMessage and RaidWarningFrame then RaidNotice_AddMessage(RaidWarningFrame, msg, ChatTypeInfo["RAID_WARNING"]) end
        switching = false
      end
    end
  end
  local leg = CHAR.leg
  local L = DATA[leg]

  -- header: zone, level, bars
  main.zone:SetText(L.z)
  main.hub:SetText(L.hub .. "  ·  lvl " .. L.lo .. "-" .. L.hi .. (CHAR.auto == false and "  ·  |cffff9933manual|r" or ""))
  local lvl = UnitLevel("player")
  local xp, xpMax = UnitXP("player"), UnitXPMax("player")
  local pct = (xpMax and xpMax > 0) and (xp / xpMax) or 0
  main.xp:SetValue(pct)
  main.lvl:SetText("Level " .. lvl .. "  |cff8a9399" .. floor(pct * 100) .. "% to " .. (lvl + 1) .. "|r")
  local d, tot = legProgress(leg)
  main.zbar:SetValue(tot > 0 and d / tot or 0)
  main.zpct:SetText(d .. "/" .. tot .. " quests")

  -- tip
  local tip = ""
  if current and current.step.t == "A" then
    local n, idx = 0, current.idx
    while idx <= #L.s and L.s[idx].t == "A" do
      if stepState(leg, idx, L.s[idx]) == "todo" then n = n + #todoNames("A", L.s[idx]) end
      idx = idx + 1
    end
    if n > 1 then tip = "Grab all " .. n .. " quests around here before you head out." end
  end
  if questLogCount() >= 18 then tip = "|cffff5555Quest log almost full (" .. questLogCount() .. "/20).|r Finish or drop something." end
  -- always say where you go next, and warn when this zone is nearly done
  local nl = nextLeg()
  if nl then
    local N = DATA[nl]
    local left = leftIn(leg)
    local line
    if left <= 4 or lvl >= L.hi then
      line = "|cffff9933Almost done here (" .. left .. " quest" .. (left == 1 and "" or "s") .. " left).|r Next: |cffffffff" .. legName(nl) ..
        "|r, lvl " .. N.lo .. "-" .. N.hi .. ".\n|cff8a9399" .. (N.tr or "") .. "|r"
    else
      line = "|cff8a9399Up next: " .. legName(nl) .. " (lvl " .. N.lo .. "-" .. N.hi .. ")|r"
    end
    tip = (tip ~= "" and (tip .. "\n") or "") .. line
  end
  main.tip:SetText(tip); main.tip:SetShown(tip ~= "")

  -- NOW card
  local card = main.card
  if current then
    local s = current.step
    local ty = TYPE[s.t] or TYPE.G
    card.icon:SetTexture(ty[1]); card.stripe:SetVertexColor(ty[2], ty[3], ty[4])
    card.kind:SetText(ty[5]); card.kind:SetTextColor(ty[2], ty[3], ty[4])
    local head, details, sub = stepCard(s)
    card.head:SetText(head)
    card.sub:SetText(sub or ""); card.sub:SetShown(sub ~= nil)
    card.body:SetText(table.concat(details or {}, "\n"))
    local k = key(current.leg, current.idx)
    if k ~= lastKey then lastKey = k; card.fade:Stop(); card.fade:Play(); shownAngle = nil end
  else
    local lvlWait, minLvl = 0, nil
    for i2, st2 in ipairs(L.s) do
      local state, why = stepState(leg, i2, st2)
      if state == "blocked" and st2.t == "A" and why and why:find("^level") then
        lvlWait = lvlWait + 1
        local n = tonumber(why:match("%d+")); if n and (not minLvl or n < minLvl) then minLvl = n end
      end
    end
    card.icon:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready"); card.stripe:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3])
    card.kind:SetText("ALL CAUGHT UP"); card.kind:SetTextColor(ACCENT[1], ACCENT[2], ACCENT[3])
    card.sub:SetShown(false)
    if lvlWait > 0 then
      card.head:SetText("Nothing left here yet")
      card.body:SetText(lvlWait .. " more quests open at level " .. minLvl .. ". Grind a bit or I'll move you on when there's something better.")
    else
      card.head:SetText("Route finished")
      card.body:SetText("Ding 60, you idiot.")
    end
  end

  -- ALSO HERE (while you're working quests: every other open objective, nearest first, live count + distance)
  -- otherwise THEN (the next steps on the route)
  local shown, idx = 0, current and current.idx + 1 or #L.s + 1
  for i = 1, #main.next do main.next[i]:Hide() end
  if current and (current.step.t == "C" or current.step.t == "T") then
    local others = {}
    for _, w in ipairs(activeList(CHAR.auto == false and CHAR.leg or nil)) do
      if not (w.leg == current.leg and w.idx == current.idx) then others[#others + 1] = w end
    end
    local maxRows = #others > 4 and 3 or 4
    for _, w in ipairs(others) do
      if shown >= maxRows then break end
      do
        shown = shown + 1
        local row, st = main.next[shown], w.step
        local ty = TYPE[st.t] or TYPE.G
        local label = st.t == "C" and (st.w ~= "" and st.w or st.q[1][2]) or shortText(st)
        local prog = ""
        if st.t == "C" and st.w ~= "" then
          for _, o in ipairs(questObjectives(st.q[1][1])) do
            if o[1]:lower():find(st.w:lower(), 1, true) then prog = o[1]:match("(%d+/%d+)") or ""; break end
          end
        end
        row.icon:SetTexture(ty[1])
        row.fs:SetText(label .. (prog ~= "" and ("  |cffffffff" .. prog .. "|r") or "") .. (w.d and ("  |cff6a7378" .. floor(w.d) .. " yd|r") or ""))
        row:Show()
      end
    end
    if #others > shown then
      shown = shown + 1
      local row = main.next[shown]
      row.icon:SetTexture(nil); row.fs:SetText("|cff6a7378+" .. (#others - shown + 1) .. " more nearby|r"); row:Show()
    end
    main.thenLabel:SetText("ALSO HERE")
  else
    main.thenLabel:SetText("THEN")
  end
  while shown < 3 and idx <= #L.s do
    local st = stepState(leg, idx, L.s[idx])
    if st == "todo" then
      shown = shown + 1
      local row = main.next[shown]
      local ty = TYPE[L.s[idx].t] or TYPE.G
      row.icon:SetTexture(ty[1]); row.fs:SetText(shortText(L.s[idx])); row:Show()
    end
    idx = idx + 1
  end
  main.thenLabel:SetShown(shown > 0)

  main.shownNext = shown
  TWI_Relayout()
  C_Timer.After(0, TWI_Relayout)        -- text re-wraps a frame later after a width change; measure again
  updateArrow()
  if TWI_OnStep then pcall(TWI_OnStep, current, activeList(CHAR.auto == false and CHAR.leg or nil), shortText) end
  if TWI_MenuRefresh then TWI_MenuRefresh() end
end
TWI_Refresh = refresh


local function savePoint(f, k)
  local p, _, rp, x, y = f:GetPoint()
  DB[k] = { p, rp, x, y }
end

local function makeMovable(f, k)
  f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
  f:SetScript("OnDragStart", function(self) if not DB.locked then self:StartMoving() end end)
  f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); savePoint(self, k) end)
  local sp = DB[k]
  if sp then f:ClearAllPoints(); f:SetPoint(sp[1], UIParent, sp[2], sp[3], sp[4]) end
end

local function button(parent, text, w, onClick)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w, 20); b:SetText(text); b:SetScript("OnClick", onClick)
  return b
end

local menu, menuLeg, refreshMenu
travelFirst = function(n)
  local here = GetRealZoneText and GetRealZoneText() or ""
  if DATA[n].z == here or hasLogWork(n) then return nil end   -- already there, or you carry its quests: no trip first
  for idx, st in ipairs(DATA[n].s) do
    if st.t == "G" then CHAR.done[key(n, idx)] = nil; CHAR.skip[key(n, idx)] = nil; return { n, idx } end
  end
end
TWI_TravelFirst = travelFirst

local function setLeg(n)
  CHAR.leg = math.max(1, math.min(#DATA, n))
  CHAR.from = travelFirst(CHAR.leg)
  CHAR.picked = true
  CHAR.auto = false
  if legList then legList:Hide() end
  refresh()
  if menu and menu:IsShown() then menuLeg = CHAR.leg; refreshMenu() end
end

-- ---------- Full guide: one clean panel in the same style as the main window ----------
-- left: zones (name, level range, hub, a thin progress line); right: the steps of the chosen zone, one quiet line each.
-- Finished steps are tucked away unless you ask for them; quest names live in the hover tooltip, not on the row.
local menuRows, zoneRows = {}, {}
local ROW_H, ZONE_H = 24, 34

local function plain(t) return ((t or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "")) end

local function scroller(parent, w)
  local sf = CreateFrame("ScrollFrame", nil, parent)
  local content = CreateFrame("Frame", nil, sf); content:SetSize(w, 10)
  sf:SetScrollChild(content)
  sf:EnableMouseWheel(true)
  sf:SetScript("OnMouseWheel", function(self, d)
    local max = math.max(0, content:GetHeight() - self:GetHeight())
    self:SetVerticalScroll(math.max(0, math.min(max, self:GetVerticalScroll() - d * 48)))
  end)
  return sf, content
end

local function pill(parent, label, tip, get, set)
  local b = flatButton(parent, label, 10, tip, function() set(not get()); refreshMenu() end)
  b:SetWidth(math.max(b.fs:GetStringWidth() or 0, #label * 6.5) + 26)
  b.sync = function(self)
    local on = get()
    if on then self.bg:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.22); self.fs:SetTextColor(1, 1, 1)
    else self.bg:SetVertexColor(1, 1, 1, 0.06); self.fs:SetTextColor(0.6, 0.63, 0.66) end
  end
  b:SetScript("OnLeave", function(self) self:sync(); GameTooltip:Hide() end)
  return b
end

function refreshMenu()
  if not menu then return end
  local leg = menuLeg or CHAR.leg
  local L = DATA[leg]
  local lvl = UnitLevel("player")

  -- zones
  for i, row in ipairs(zoneRows) do
    local Z = DATA[i]
    local d, t = legProgress(i)
    row.name:SetText(Z.z)
    row.sub:SetText(Z.lo .. "-" .. Z.hi .. "  ·  " .. Z.hub)
    row.count:SetText(t > 0 and (d .. "/" .. t) or "")
    row.prog:SetValue(t > 0 and d / t or 0)
    local sel, cur = (i == leg), (i == CHAR.leg)
    row.bg:SetVertexColor(1, 1, 1, sel and 0.08 or 0)
    row.stripe:SetShown(cur)
    local fit = lvl >= Z.lo - 1 and lvl < Z.hi
    local done = t > 0 and d >= t
    local c = (sel or cur) and 1 or (done and 0.42 or (fit and 0.88 or 0.62))
    row.name:SetTextColor(c, c, c)
    if done then row.count:SetTextColor(ACCENT[1], ACCENT[2], ACCENT[3]) else row.count:SetTextColor(0.5, 0.53, 0.56) end
  end

  -- header
  menu.zone:SetText(L.z)
  menu.zsub:SetText("Level " .. L.lo .. "-" .. L.hi .. "  ·  " .. L.hub .. (leg == CHAR.leg and "  ·  |cff2ef299you're following this zone|r" or ""))
  menu.trv:SetText(L.tr or "")

  -- steps
  local cur = (leg == CHAR.leg) and current and current.leg == leg and current.idx or nil
  local y, hidden = 0, 0
  for idx, s in ipairs(L.s) do
    local row = menuRows[idx]
    if not row then
      row = CreateFrame("Button", nil, menu.content)
      row:SetHeight(ROW_H)
      row.bg = fill(row, 1, 1, 1, 0)
      row.mark = row:CreateTexture(nil, "ARTWORK"); row.mark:SetTexture(WHITE); row.mark:SetSize(3, ROW_H - 8); row.mark:SetPoint("LEFT", 0, 0)
      row.icon = row:CreateTexture(nil, "ARTWORK"); row.icon:SetSize(14, 14); row.icon:SetPoint("LEFT", 12, 0)
      row.fs = text(row, 12, 0.9, 0.92, 0.94); row.fs:SetPoint("LEFT", row.icon, "RIGHT", 10, 0); row.fs:SetPoint("RIGHT", -8, 0)
      row.fs:SetWordWrap(false)
      row:SetScript("OnEnter", function(self)
        self.bg:SetVertexColor(1, 1, 1, 0.06)
        local st = DATA[menuLeg or CHAR.leg].s[self.idx]
        if st then
          GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
          GameTooltip:AddLine(plain(shortText(st)), 1, 1, 1)
          for _, q in ipairs(st.q or {}) do GameTooltip:AddLine(q[2], 0.75, 0.78, 0.8) end
          if st.i and st.i ~= "" then GameTooltip:AddLine(st.i, 0.55, 0.58, 0.6, true) end
          GameTooltip:AddLine("Click to jump here", ACCENT[1], ACCENT[2], ACCENT[3])
          GameTooltip:Show()
        end
      end)
      row:SetScript("OnLeave", function(self) self.bg:SetVertexColor(1, 1, 1, self.isCur and 0.05 or 0); GameTooltip:Hide() end)
      row:SetScript("OnClick", function(self)
        local ml = menuLeg or CHAR.leg
        local k = key(ml, self.idx)
        CHAR.leg = ml; CHAR.pin = { ml, self.idx }; CHAR.from = nil
        CHAR.skip[k] = nil; CHAR.done[k] = nil
        refresh(); refreshMenu()
      end)
      menuRows[idx] = row
    end
    row.idx = idx
    local st = stepState(leg, idx, s)
    local finished = (st == "done" or st == "skipped")
    if finished and not DB.showDone and idx ~= cur then
      row:Hide(); hidden = hidden + 1
    else
      local ty = TYPE[s.t] or TYPE.G
      row.icon:SetTexture(finished and "Interface\\RaidFrame\\ReadyCheck-Ready" or ty[1])
      if row.icon.SetDesaturated then row.icon:SetDesaturated(st == "blocked") end
      row.isCur = (idx == cur)
      row.mark:SetShown(row.isCur); row.mark:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3])
      row.bg:SetVertexColor(1, 1, 1, row.isCur and 0.05 or 0)
      row.fs:SetText(plain(shortText(s)))
      if row.isCur then row.fs:SetTextColor(1, 1, 1)
      elseif finished then row.fs:SetTextColor(0.42, 0.45, 0.48)
      elseif st == "blocked" then row.fs:SetTextColor(0.5, 0.53, 0.56)
      else row.fs:SetTextColor(0.86, 0.88, 0.9) end
      row:ClearAllPoints(); row:SetPoint("TOPLEFT", 0, -y); row:SetPoint("RIGHT", menu.content, "RIGHT", 0, 0)
      row:Show(); y = y + ROW_H
    end
  end
  for idx = #L.s + 1, #menuRows do menuRows[idx]:Hide() end
  menu.content:SetHeight(math.max(10, y + 4))
  menu.hiddenNote:SetText(hidden > 0 and (hidden .. " finished step" .. (hidden == 1 and "" or "s") .. " hidden") or "")
  for _, p in ipairs(menu.pills) do p:sync() end
  menu.size:SetText(floor((DB.arrowScale or 1) * 100 + 0.5) .. "%")
  menu.autoB.fs:SetText(CHAR.auto ~= false and "Automatic: on" or "Automatic: off")
end

local function buildMenu()
  menu = CreateFrame("Frame", "ThisWayIdiotMenu", UIParent)
  menu:SetSize(760, 530); menu:SetPoint("CENTER"); menu:SetFrameStrata("DIALOG")
  fill(menu, 0.045, 0.05, 0.058, 0.97)
  border(menu, ACCENT[1], ACCENT[2], ACCENT[3], 0.35)
  menu:EnableMouse(true)
  makeMovable(menu, "menuPos")
  tinsert(UISpecialFrames, "ThisWayIdiotMenu")

  local title = text(menu, 13, ACCENT[1], ACCENT[2], ACCENT[3]); title:SetPoint("TOPLEFT", 18, -16); title:SetText("THIS WAY IDIOT")
  local tsub = text(menu, 11, 0.5, 0.53, 0.56); tsub:SetPoint("LEFT", title, "RIGHT", 10, 0); tsub:SetText("Full guide  ·  Horde 20-60")
  local close = flatButton(menu, "x", 24, nil, function() menu:Hide() end); close:SetPoint("TOPRIGHT", -12, -10)

  local line = menu:CreateTexture(nil, "BORDER"); line:SetTexture(WHITE); line:SetVertexColor(1, 1, 1, 0.07)
  line:SetPoint("TOPLEFT", 12, -44); line:SetPoint("TOPRIGHT", -12, -44); line:SetHeight(1)

  -- left: zones
  local zsf, zc = scroller(menu, 236)
  zsf:SetPoint("TOPLEFT", 12, -52); zsf:SetPoint("BOTTOMLEFT", 12, 86); zsf:SetWidth(236)
  for i in ipairs(DATA) do
    local r = CreateFrame("Button", nil, zc)
    r:SetSize(236, ZONE_H); r:SetPoint("TOPLEFT", 0, -(i - 1) * ZONE_H)
    r.bg = fill(r, 1, 1, 1, 0)
    r.stripe = r:CreateTexture(nil, "ARTWORK"); r.stripe:SetTexture(WHITE); r.stripe:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3])
    r.stripe:SetPoint("TOPLEFT", 0, -6); r.stripe:SetPoint("BOTTOMLEFT", 0, 6); r.stripe:SetWidth(3)
    r.name = text(r, 12, 1, 1, 1); r.name:SetPoint("TOPLEFT", 12, -5); r.name:SetPoint("RIGHT", -44, 0); r.name:SetWordWrap(false)
    r.sub = text(r, 10, 0.5, 0.53, 0.56); r.sub:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -2); r.sub:SetPoint("RIGHT", -10, 0); r.sub:SetWordWrap(false)
    r.count = text(r, 10, 0.5, 0.53, 0.56); r.count:SetPoint("TOPRIGHT", -10, -6); r.count:SetJustifyH("RIGHT")
    r.prog = bar(r, ACCENT[1], ACCENT[2], ACCENT[3]); r.prog:SetHeight(1)
    r.prog:SetPoint("BOTTOMLEFT", 12, 2); r.prog:SetPoint("BOTTOMRIGHT", -10, 2)
    r:SetScript("OnEnter", function(self) if (menuLeg or CHAR.leg) ~= i then self.bg:SetVertexColor(1, 1, 1, 0.04) end end)
    r:SetScript("OnLeave", function() refreshMenu() end)
    r:SetScript("OnClick", function() menuLeg = i; refreshMenu() end)
    zoneRows[i] = r
  end
  zc:SetHeight(#DATA * ZONE_H)

  local vline = menu:CreateTexture(nil, "BORDER"); vline:SetTexture(WHITE); vline:SetVertexColor(1, 1, 1, 0.07)
  vline:SetPoint("TOPLEFT", 258, -52); vline:SetPoint("BOTTOMLEFT", 258, 86); vline:SetWidth(1)

  -- right: zone header + steps
  menu.zone = text(menu, 17, 1, 1, 1); menu.zone:SetPoint("TOPLEFT", 274, -56); menu.zone:SetPoint("RIGHT", -18, 0)
  menu.zsub = text(menu, 11, 0.5, 0.53, 0.56); menu.zsub:SetPoint("TOPLEFT", menu.zone, "BOTTOMLEFT", 0, -4); menu.zsub:SetPoint("RIGHT", -18, 0)
  menu.trv = text(menu, 11, 0.7, 0.72, 0.74); menu.trv:SetPoint("TOPLEFT", menu.zsub, "BOTTOMLEFT", 0, -6); menu.trv:SetPoint("RIGHT", -18, 0)
  menu.trv:SetWordWrap(true)
  local sf, content = scroller(menu, 466)
  sf:SetPoint("TOPLEFT", 268, -118); sf:SetPoint("BOTTOMRIGHT", -14, 106)
  menu.content = content
  menu.hiddenNote = text(menu, 10, 0.45, 0.48, 0.5); menu.hiddenNote:SetPoint("BOTTOMLEFT", 274, 90)

  -- bottom bar
  local bl = menu:CreateTexture(nil, "BORDER"); bl:SetTexture(WHITE); bl:SetVertexColor(1, 1, 1, 0.07)
  bl:SetPoint("BOTTOMLEFT", 12, 78); bl:SetPoint("BOTTOMRIGHT", -12, 78); bl:SetHeight(1)
  menu.autoB = flatButton(menu, "Automatic: on", 112, "Let the guide pick your zone by level and what you've done.",
    function() CHAR.auto = true; CHAR.picked = nil; CHAR.leg = bestLeg(); CHAR.from = nil; CHAR.pin = nil; menuLeg = CHAR.leg; refresh(); refreshMenu() end)
  menu.autoB:SetPoint("BOTTOMLEFT", 16, 44)
  local follow = flatButton(menu, "Follow this zone", 120, "Guide this zone (turns Automatic off).", function() setLeg(menuLeg or CHAR.leg) end)
  follow:SetPoint("LEFT", menu.autoB, "RIGHT", 8, 0)
  menu.pills = {
    pill(menu, "Show finished", "Show steps you've already done.", function() return DB.showDone end, function(v) DB.showDone = v end),
    pill(menu, "Arrow", "Show the arrow.", function() return DB.arrow end, function(v) DB.arrow = v; refresh() end),
    pill(menu, "Lock windows", "Stop the windows from being dragged.", function() return DB.locked end, function(v) DB.locked = v end),
    pill(menu, "Auto quests", "Accept and turn in the guide's quests for you (reward choices stay yours). Hold Shift to do it yourself.", function() return DB.autoQuest ~= false end, function(v) DB.autoQuest = v end),
    pill(menu, "Map pins", "Show the current target and nearby objectives on the world map and minimap.", function() return DB.pins ~= false end, function(v) DB.pins = v; refresh() end),
    pill(menu, "Sell junk + repair", "Sell gray items and repair at any vendor. Hold Shift to skip.", function() return DB.autoJunk ~= false end, function(v) DB.autoJunk = v; DB.autoRepair = v end),
  }
  menu.pills[1]:SetPoint("BOTTOMLEFT", 16, 14)
  for i = 2, #menu.pills do menu.pills[i]:SetPoint("LEFT", menu.pills[i - 1], "RIGHT", 6, 0) end
  local plus = flatButton(menu, "+", 22, "Bigger arrow", function() DB.arrowScale = math.min(2.5, (DB.arrowScale or 1) + 0.1); arrow:SetScale(DB.arrowScale); refreshMenu() end)
  plus:SetPoint("BOTTOMRIGHT", -16, 44)
  menu.size = text(menu, 11, 0.85, 0.88, 0.9); menu.size:SetPoint("RIGHT", plus, "LEFT", -6, 0); menu.size:SetJustifyH("RIGHT")
  local minus = flatButton(menu, "-", 22, "Smaller arrow", function() DB.arrowScale = math.max(0.5, (DB.arrowScale or 1) - 0.1); arrow:SetScale(DB.arrowScale); refreshMenu() end)
  minus:SetPoint("RIGHT", menu.size, "LEFT", -6, 0)
  local al = text(menu, 10, 0.5, 0.53, 0.56); al:SetPoint("RIGHT", minus, "LEFT", -8, 0); al:SetText("Arrow size")

  menu:SetScript("OnShow", function()
    menuLeg = menuLeg or CHAR.leg; refreshMenu()
    local maxs = math.max(0, #DATA * ZONE_H - (zsf:GetHeight() or 0))
    zsf:SetVerticalScroll(math.max(0, math.min(maxs, (menuLeg - 3) * ZONE_H)))
  end)
  menu:Hide()
end

TWI_MenuRefresh = function() if menu and menu:IsShown() then refreshMenu() end end

local function toggleMenu()
  if menu:IsShown() then menu:Hide() else menuLeg = CHAR.leg; menu:Show() end
end

local function skipCurrent()
  if current then CHAR.skip[key(current.leg, current.idx)] = true; refresh() end
end

local BACKDROP = { bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 14, insets = { left = 4, right = 4, top = 4, bottom = 4 } }

local function buildLegList()
  legList = CreateFrame("Frame", "ThisWayIdiotLegs", UIParent, BackdropTemplateMixin and "BackdropTemplate")
  legList:SetSize(420, 44 + math.ceil(#DATA / 2) * 22)
  legList:SetPoint("CENTER"); legList:SetFrameStrata("DIALOG")
  legList:SetBackdrop(BACKDROP); legList:SetBackdropColor(0, 0, 0, 0.92)
  local t = legList:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  t:SetPoint("TOP", 0, -10); t:SetText("This Way Idiot: pick a zone")
  for i, L in ipairs(DATA) do
    local col, row = (i - 1) % 2, floor((i - 1) / 2)
    local b = button(legList, string.format("%d. %s %d-%d", i, L.z, L.lo, L.hi), 196, function() setLeg(i) end)
    b:SetPoint("TOPLEFT", 12 + col * 200, -32 - row * 22)
  end
  local close = CreateFrame("Button", nil, legList, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 2, 2)
  makeMovable(legList, "legsPos")
  tinsert(UISpecialFrames, "ThisWayIdiotLegs")
  legList:Hide()
end

local function buildMain()
  main = CreateFrame("Frame", "ThisWayIdiotFrame", UIParent)
  main:SetSize(DB.mainW or 340, 200)
  main:SetPoint("RIGHT", UIParent, "RIGHT", -40, 80)
  main:SetFrameStrata("MEDIUM")
  fill(main, 0.045, 0.05, 0.058, 0.93)
  border(main, ACCENT[1], ACCENT[2], ACCENT[3], 0.35)
  makeMovable(main, "mainPos")
  main:SetScale(DB.mainScale or 1)
  main:SetClipsChildren(true)

  -- header strip
  local hdr = CreateFrame("Frame", nil, main)
  hdr:SetPoint("TOPLEFT", 1, -1); hdr:SetPoint("TOPRIGHT", -1, -1); hdr:SetHeight(22)
  fill(hdr, 1, 1, 1, 0.04)
  local logo = hdr:CreateTexture(nil, "ARTWORK"); logo:SetTexture("Interface\\AddOns\\" .. ADDON .. "\\arrow")
  logo:SetSize(13, 13); logo:SetPoint("LEFT", 8, 0); logo:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3])
  local brand = text(hdr, 10, ACCENT[1], ACCENT[2], ACCENT[3], "OUTLINE"); brand:SetPoint("LEFT", logo, "RIGHT", 5, 0)
  brand:SetText("THIS WAY IDIOT")
  main.lvl = text(hdr, 10, 0.9, 0.92, 0.95); main.lvl:SetPoint("RIGHT", -26, 0); main.lvl:SetJustifyH("RIGHT")
  local close = CreateFrame("Button", nil, hdr)
  close:SetSize(18, 18); close:SetPoint("RIGHT", -3, 0)
  close.fs = text(close, 14, 0.6, 0.65, 0.7); close.fs:SetPoint("CENTER", 0, 1); close.fs:SetText("×")
  close:SetScript("OnEnter", function(self) self.fs:SetTextColor(1, 0.4, 0.4) end)
  close:SetScript("OnLeave", function(self) self.fs:SetTextColor(0.6, 0.65, 0.7) end)
  close:SetScript("OnClick", function()
    main:Hide(); DB.hidden = true
    print("|cff33ff99This Way Idiot|r hidden (the arrow stays on). Type |cffffd100/idiot|r to bring it back.")
  end)
  main.xp = bar(main, 0.62, 0.45, 1); main.xp:SetPoint("TOPLEFT", hdr, "BOTTOMLEFT", 0, 0); main.xp:SetPoint("TOPRIGHT", hdr, "BOTTOMRIGHT", 0, 0)
  main.xp:SetHeight(2)

  -- zone line
  main.zone = text(main, 15, 1, 1, 1); main.zone:SetPoint("TOPLEFT", 10, -32); main.zone:SetPoint("RIGHT", -90, 0)
  main.zone:SetWordWrap(false)
  main.zpct = text(main, 10, 0.55, 0.6, 0.65); main.zpct:SetPoint("TOPRIGHT", -10, -35); main.zpct:SetJustifyH("RIGHT")
  main.hub = text(main, 10, 0.55, 0.6, 0.65); main.hub:SetPoint("TOPLEFT", main.zone, "BOTTOMLEFT", 0, -2)
  main.zbar = bar(main, ACCENT[1], ACCENT[2], ACCENT[3])
  main.zbar:SetPoint("TOPLEFT", main.hub, "BOTTOMLEFT", 0, -5); main.zbar:SetPoint("RIGHT", main, "RIGHT", -10, 0)

  main.tip = text(main, 11, 1, 0.82, 0.3); main.tip:SetPoint("TOPLEFT", main.zbar, "BOTTOMLEFT", 0, -8)
  main.tip:SetPoint("RIGHT", main, "RIGHT", -10, 0); main.tip:SetWordWrap(true)

  -- NOW card
  local card = CreateFrame("Frame", nil, main)
  card:SetPoint("TOPLEFT", main.tip, "BOTTOMLEFT", 0, -8); card:SetPoint("RIGHT", main, "RIGHT", -10, 0)
  card:SetHeight(80)
  fill(card, 1, 1, 1, 0.045)
  card.stripe = card:CreateTexture(nil, "ARTWORK"); card.stripe:SetTexture(WHITE)
  card.stripe:SetPoint("TOPLEFT"); card.stripe:SetPoint("BOTTOMLEFT"); card.stripe:SetWidth(3)
  card.icon = card:CreateTexture(nil, "ARTWORK"); card.icon:SetSize(30, 30); card.icon:SetPoint("TOPLEFT", 12, -10)
  card.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
  card.kind = text(card, 9, 1, 1, 1, "OUTLINE"); card.kind:SetPoint("TOPLEFT", card.icon, "TOPRIGHT", 10, 1)
  card.head = text(card, 14, 1, 1, 1); card.head:SetPoint("TOPLEFT", card.kind, "BOTTOMLEFT", 0, -3)
  card.head:SetPoint("RIGHT", card, "RIGHT", -10, 0); card.head:SetWordWrap(true)
  card.sub = text(card, 11, 0.6, 0.66, 0.72); card.sub:SetPoint("TOPLEFT", card.head, "BOTTOMLEFT", 0, -2)
  card.sub:SetPoint("RIGHT", card, "RIGHT", -10, 0)
  card.body = text(card, 11, 0.78, 0.82, 0.86); card.body:SetPoint("TOPLEFT", card.sub, "BOTTOMLEFT", 0, -6)
  card.body:SetPoint("RIGHT", card, "RIGHT", -10, 0); card.body:SetWordWrap(true); card.body:SetSpacing(3)
  card.fade = card:CreateAnimationGroup()
  local a = card.fade:CreateAnimation("Alpha"); a:SetFromAlpha(0.15); a:SetToAlpha(1); a:SetDuration(0.35); a:SetSmoothing("OUT")
  main.card = card

  -- THEN list
  main.thenLabel = text(main, 9, 0.45, 0.5, 0.55, "OUTLINE"); main.thenLabel:SetPoint("TOPLEFT", card, "BOTTOMLEFT", 2, -10)
  main.thenLabel:SetText("THEN")
  main.next = {}
  local prev = main.thenLabel
  for i = 1, 5 do
    local row = CreateFrame("Frame", nil, main); row:SetHeight(18)
    row:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, i == 1 and -4 or 0); row:SetPoint("RIGHT", main, "RIGHT", -10, 0)
    row.icon = row:CreateTexture(nil, "ARTWORK"); row.icon:SetSize(13, 13); row.icon:SetPoint("LEFT", 0, 0)
    row.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93); row.icon:SetAlpha(0.7)
    row.fs = text(row, 11, 0.6, 0.64, 0.68); row.fs:SetPoint("LEFT", row.icon, "RIGHT", 7, 0); row.fs:SetPoint("RIGHT", 0, 0)
    row.fs:SetWordWrap(false)
    main.next[i] = row; prev = row
  end

  -- footer buttons
  local bSkip = flatButton(main, "Skip step", 78, "Skip this step. It won't come back (unless you click it in the full guide).", skipCurrent)
  bSkip:SetPoint("BOTTOMLEFT", 10, 10)
  local bGuide = flatButton(main, "Full guide", 78, "Every zone and every step. Click any step to jump to it.", function() toggleMenu() end)
  bGuide:SetPoint("LEFT", bSkip, "RIGHT", 6, 0)
  local bArrow = flatButton(main, "Arrow", 56, "Show or hide the direction arrow.", function() DB.arrow = not DB.arrow; refresh() end)
  bArrow:SetPoint("LEFT", bGuide, "RIGHT", 6, 0)

  -- resize grip (wider / slimmer) + Ctrl+wheel scale
  main:SetResizable(true)
  if main.SetResizeBounds then main:SetResizeBounds(260, 140, 900, 1200)
  elseif main.SetMinResize then main:SetMinResize(260, 140); main:SetMaxResize(900, 1200) end
  local grip = CreateFrame("Button", nil, main)
  grip:SetSize(14, 14); grip:SetPoint("BOTTOMRIGHT", -2, 2)
  grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
  grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
  grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
  grip:SetScript("OnMouseDown", function() if not DB.locked then main.sizing = true; main:StartSizing("RIGHT") end end)
  grip:SetScript("OnMouseUp", function()
    main:StopMovingOrSizing(); main.sizing = false
    DB.mainW = floor(main:GetWidth()); savePoint(main, "mainPos"); refresh()
  end)
  local lastW = 0
  main:SetScript("OnSizeChanged", function(self, w)
    if abs((w or 0) - lastW) > 0.5 then lastW = w or 0; C_Timer.After(0, TWI_Relayout) end
  end)
  main:EnableMouseWheel(true)
  main:SetScript("OnMouseWheel", function(_, d)
    if not IsControlKeyDown() then return end
    DB.mainScale = math.max(0.6, math.min(2, (DB.mainScale or 1) + d * 0.05))
    main:SetScale(DB.mainScale)
  end)
end

local function buildArrow()
  arrow = CreateFrame("Frame", "ThisWayIdiotArrow", UIParent)
  arrow:SetSize(120, 130)
  arrow:SetPoint("TOP", UIParent, "TOP", 0, -90)
  makeMovable(arrow, "arrowPos")
  local base = "Interface\\AddOns\\" .. ADDON .. "\\"
  arrow.glow = arrow:CreateTexture(nil, "BACKGROUND"); arrow.glow:SetTexture(base .. "glow")
  arrow.glow:SetSize(110, 110); arrow.glow:SetPoint("TOP", 0, 10); arrow.glow:SetBlendMode("ADD")
  arrow.shadow = arrow:CreateTexture(nil, "BORDER"); arrow.shadow:SetTexture(base .. "arrow_shadow")
  arrow.shadow:SetSize(68, 68); arrow.shadow:SetPoint("TOP", 2, -6)
  arrow.tex = arrow:CreateTexture(nil, "ARTWORK"); arrow.tex:SetTexture(base .. "arrow")
  arrow.tex:SetSize(64, 64); arrow.tex:SetPoint("TOP", 0, -2)
  arrow.ring = arrow:CreateTexture(nil, "OVERLAY"); arrow.ring:SetTexture(base .. "ring")
  arrow.ring:SetSize(70, 70); arrow.ring:SetPoint("CENTER", arrow.tex, "CENTER"); arrow.ring:SetAlpha(0)
  arrow.ring:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3])
  arrow.pulse = arrow.ring:CreateAnimationGroup()
  local s1 = arrow.pulse:CreateAnimation("Scale"); s1:SetScale(1.8, 1.8); s1:SetDuration(0.7); s1:SetSmoothing("OUT")
  local a1 = arrow.pulse:CreateAnimation("Alpha"); a1:SetFromAlpha(0.9); a1:SetToAlpha(0); a1:SetDuration(0.7)
  arrow.dist = text(arrow, 16, 1, 1, 1, "OUTLINE"); arrow.dist:SetPoint("TOP", arrow.tex, "BOTTOM", 0, -4)
  arrow.dist:SetJustifyH("CENTER")
  arrow.label = text(arrow, 11, 0.85, 0.88, 0.92, "OUTLINE"); arrow.label:SetPoint("TOP", arrow.dist, "BOTTOM", 0, -2)
  arrow.label:SetWidth(280); arrow.label:SetJustifyH("CENTER")
  local acc = 0
  arrow:SetScript("OnUpdate", function(_, e)
    acc = acc + e
    if acc > 0.03 then updateArrow(acc); acc = 0 end
  end)
end

-- ---------- events ----------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
local pending = false
local function queueRefresh()
  if pending then return end
  pending = true
  C_Timer.After(0.3, function() pending = false; refresh() end)
end

-- ---------- learn from the NPC: the arrow must never point at a quest the game won't give you ----------
-- When a quest giver's window opens, any route pickup at that NPC that isn't in their list gets parked
-- (CHAR.na[questID] = your level) until you level up or turn something in. Quests the data thinks are open
-- but the NPC doesn't offer (missing prerequisite, race/class only, changed in Forever) stop showing.
local npcWatch = CreateFrame("Frame")
for _, e in ipairs({ "GOSSIP_SHOW", "QUEST_GREETING", "QUEST_TURNED_IN" }) do pcall(npcWatch.RegisterEvent, npcWatch, e) end
npcWatch:SetScript("OnEvent", function(_, e)
  if not CHAR then return end
  if e == "QUEST_TURNED_IN" then CHAR.na = nil; return end
  if e ~= "GOSSIP_SHOW" and e ~= "QUEST_GREETING" then return end
  local npc = UnitName("npc")
  if not npc then return end
  local offered = {}
  if e == "GOSSIP_SHOW" then
    if not (C_GossipInfo and C_GossipInfo.GetAvailableQuests) then return end
    for _, q in ipairs(C_GossipInfo.GetAvailableQuests() or {}) do if q.questID then offered[q.questID] = true end end
  else
    if not (GetNumAvailableQuests and GetAvailableQuestInfo) then return end
    for i = 1, GetNumAvailableQuests() do
      local id = select(5, GetAvailableQuestInfo(i))
      if not id then return end          -- this client doesn't report IDs here; don't guess
      offered[id] = true
    end
  end
  local lvl, parked = UnitLevel("player"), 0
  for _, L in ipairs(DATA) do
    for _, s in ipairs(L.s) do
      if s.t == "A" and s.w == npc then
        for _, q in ipairs(s.q or {}) do
          local id = q[1]
          if not offered[id] and not logIndex(id) and not isCompleted(id) then
            CHAR.na = CHAR.na or {}
            if CHAR.na[id] ~= lvl then CHAR.na[id] = lvl; parked = parked + 1 end
          end
        end
      end
    end
  end
  if parked > 0 then queueRefresh() end
end)

local function tickIf(t)
  if current and current.step.t == t then
    local d = distanceTo(current.step)
    if d == nil or d < 60 then CHAR.done[key(current.leg, current.idx)] = true end
  end
end

local function trainerNotice(lvl)
  if lvl < 10 or lvl % 2 == 1 then return end
  local msg = "Level " .. lvl .. "! New " .. (UnitClass("player") or "class") .. " spells: train next time you're in a city."
  print("|cff33ff99This Way Idiot:|r " .. msg)
  if RaidNotice_AddMessage and RaidWarningFrame then RaidNotice_AddMessage(RaidWarningFrame, msg, ChatTypeInfo["RAID_WARNING"]) end
end

ev:SetScript("OnEvent", function(self, e, arg)
  if e == "ADDON_LOADED" and arg == ADDON then
    ThisWayIdiotDB = ThisWayIdiotDB or {}
    ThisWayIdiotChar = ThisWayIdiotChar or {}
    DB, CHAR = ThisWayIdiotDB, ThisWayIdiotChar
    if DB.arrow == nil then DB.arrow = true end      -- arrow is on out of the box
    CHAR.skip = CHAR.skip or {}
    CHAR.done = CHAR.done or {}
  elseif e == "PLAYER_LOGIN" then
    if type(CHAR.leg) ~= "number" or not DATA[CHAR.leg] then CHAR.leg = nil end
    if CHAR.from and not (type(CHAR.from) == "table" and DATA[CHAR.from[1]] and DATA[CHAR.from[1]].s[CHAR.from[2] or 0]
      and DATA[CHAR.from[1]].s[CHAR.from[2]].t == "G") then CHAR.from = nil end
    if CHAR.pin and not (type(CHAR.pin) == "table" and DATA[CHAR.pin[1]] and DATA[CHAR.pin[1]].s[CHAR.pin[2] or 0]) then CHAR.pin = nil end
    if not CHAR.leg then CHAR.leg = defaultLeg() end
    buildMain(); buildArrow(); buildLegList(); buildMenu()
    arrow:SetScale(DB.arrowScale or 1)
    if DB.hidden then main:Hide() end
    for _, n in ipairs({ "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_TURNED_IN", "QUEST_REMOVED", "PLAYER_LEVEL_UP",
      "ZONE_CHANGED_NEW_AREA", "TAXIMAP_OPENED", "MERCHANT_CLOSED", "HEARTHSTONE_BOUND", "PLAYER_ENTERING_WORLD",
      "PLAYER_DEAD", "PLAYER_ALIVE", "PLAYER_UNGHOST" }) do
      pcall(self.RegisterEvent, self, n)
    end
    -- arrival poll: walking into a "Go to" spot ticks it (independent of the arrow so it works with the arrow off)
    local poll, el = CreateFrame("Frame"), 0
    local lastX, lastY
    poll:SetScript("OnUpdate", function(_, dt)
      el = el + dt
      if el < 0.25 then return end
      el = 0
      local mx, my = playerPos()
      if mx and (not lastX or (mx - lastX) ^ 2 + (my - lastY) ^ 2 > 1600) then
        local first = not lastX
        lastX, lastY = mx, my
        if not first and current and (current.step.t == "C" or current.step.t == "T") then queueRefresh() end
      end
      if current and current.step.t == "G" then
        local d = distanceTo(current.step)
        if d and d < 45 then CHAR.done[key(current.leg, current.idx)] = true; refresh() end
      end
    end)
    -- quest history needs a moment after login on Classic clients; scan once it's ready
    C_Timer.After(3, function()
      local done, total = 0, 0
      for i = 1, #DATA do local d, t = legProgress(i); done = done + d; total = total + t end
      if CHAR.auto ~= false then CHAR.leg = bestLeg() end
      refresh()
      print("|cff33ff99This Way Idiot|r scanned your quest history: " .. done .. " of " .. total ..
        " route quests already done and skipped. You're level " .. UnitLevel("player") .. ": go to " .. legName(CHAR.leg) .. ". Follow the arrow.")
    end)
    refresh()
  elseif e == "TAXIMAP_OPENED" then
    CHAR.fp = CHAR.fp or {}
    if NumTaxiNodes and TaxiNodeName then
      for i = 1, NumTaxiNodes() do
        local typ = TaxiNodeGetType and TaxiNodeGetType(i)
        if typ == "CURRENT" or typ == "REACHABLE" then CHAR.fp[TaxiNodeName(i)] = true end
      end
    end
    tickIf("F"); queueRefresh()
  elseif e == "MERCHANT_CLOSED" then
    tickIf("V"); queueRefresh()
  elseif e == "PLAYER_LEVEL_UP" then
    trainerNotice(arg or UnitLevel("player")); C_Timer.After(1, refresh)
  else
    queueRefresh()
  end
end)

-- ---------- slash ----------
SLASH_THISWAYIDIOT1 = "/idiot"
SLASH_THISWAYIDIOT2 = "/twi"
SlashCmdList.THISWAYIDIOT = function(msg)
  msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  if msg == "" then
    if main:IsShown() then main:Hide(); DB.hidden = true else main:Show(); DB.hidden = false; refresh() end
  elseif msg == "why" then
    local c = findCurrent()
    print("|cff33ff99This Way Idiot|r now: " .. (c and (shortText(c.step) .. "  (" .. (c.why or "next step on the route") .. ")") or "nothing"))
    for i, w in ipairs(activeList(CHAR.auto == false and CHAR.leg or nil)) do
      if i > 6 then break end
      print("   " .. shortText(w.step) .. "  " .. floor(w.d) .. " yd")
    end
  elseif msg == "menu" or msg == "guide" then toggleMenu()
  elseif msg == "auto" then CHAR.auto = true; CHAR.picked = nil; CHAR.leg = bestLeg(); CHAR.from = nil; CHAR.pin = nil; refresh()
  elseif msg == "zones" or msg == "legs" then legList:Show()
  elseif msg == "skip" or msg == "done" then skipCurrent()
  elseif msg == "arrow" then DB.arrow = not DB.arrow; refresh()
  elseif msg == "group" or msg == "lfg" then if TWI_GroupToggle then TWI_GroupToggle() end
  elseif msg == "reset" then
    CHAR.skip = {}; CHAR.done = {}; CHAR.from = nil; CHAR.picked = nil; CHAR.leg = defaultLeg(); DB.mainPos = nil; DB.arrowPos = nil; DB.menuPos = nil; DB.hidden = nil; DB.locked = nil; DB.arrowScale = nil
    print("|cff33ff99This Way Idiot|r reset. Type /reload to put the windows back in place.")
    refresh()
  elseif tonumber(msg) then setLeg(tonumber(msg))
  else
    print("|cff33ff99This Way Idiot|r: /idiot (show/hide), /idiot menu, /idiot zones, /idiot <zone number>, /idiot skip, /idiot arrow, /idiot group, /idiot reset")
  end
end
