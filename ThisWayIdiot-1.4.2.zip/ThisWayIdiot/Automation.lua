-- This Way Idiot: automation (our own code). Accepts and turns in the guide's quests, sells gray junk, repairs.
-- Hold Shift when you talk to an NPC to do it yourself. Each part can be switched off in the Full guide.
-- Only quests that are on the route are touched; reward choices are always left to you.
local ADDON = ...
local DB
local GUIDE = {}          -- questID -> { lo, hi } level window of the route zones that use it

local function on(k) return DB and DB[k] ~= false end
local function paused() return IsShiftKeyDown and IsShiftKeyDown() end

local function buildSet()
  for _, L in ipairs(TWI_DATA or {}) do
    for _, s in ipairs(L.s) do
      for _, q in ipairs(s.q or {}) do
        local g = GUIDE[q[1]]
        if g then g[1] = math.min(g[1], L.lo); g[2] = math.max(g[2], L.hi) else GUIDE[q[1]] = { L.lo, L.hi } end
      end
    end
  end
end

-- pick-ups only for route quests that fit your level now (Astra r2: plan-aware, not the whole catalog);
-- turn-ins for any route quest you carry
local function canTake(id)
  local g = GUIDE[id]
  local lvl = UnitLevel("player")
  return g and lvl >= g[1] - 3 and lvl <= g[2] + 2
end

local function say(msg) print("|cff33ff99This Way Idiot:|r " .. msg) end

-- gossip / greeting windows: open the first guide quest to turn in, then the first to pick up
local function gossip()
  if not on("autoQuest") or paused() then return end
  if C_GossipInfo and C_GossipInfo.GetActiveQuests then
    for _, q in ipairs(C_GossipInfo.GetActiveQuests() or {}) do
      if q.isComplete and GUIDE[q.questID] then return C_GossipInfo.SelectActiveQuest(q.questID) end
    end
    for _, q in ipairs(C_GossipInfo.GetAvailableQuests() or {}) do
      if canTake(q.questID) then return C_GossipInfo.SelectAvailableQuest(q.questID) end
    end
  end
end

local function greeting()
  if not on("autoQuest") or paused() then return end
  if GetNumActiveQuests and GetActiveTitle then
    for i = 1, GetNumActiveQuests() do
      local _, complete = GetActiveTitle(i)
      local id = GetActiveQuestID and GetActiveQuestID(i)
      if complete and id and GUIDE[id] then return SelectActiveQuest(i) end
    end
  end
  if GetNumAvailableQuests and GetAvailableQuestInfo then
    for i = 1, GetNumAvailableQuests() do
      local id = select(5, GetAvailableQuestInfo(i))
      if id and canTake(id) then return SelectAvailableQuest(i) end
    end
  end
end

local function questID() return GetQuestID and GetQuestID() or 0 end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(self, e, arg)
  if e == "ADDON_LOADED" and arg == ADDON then
    ThisWayIdiotDB = ThisWayIdiotDB or {}
    DB = ThisWayIdiotDB
    buildSet()
    for _, ev in ipairs({ "GOSSIP_SHOW", "QUEST_GREETING", "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE", "MERCHANT_SHOW" }) do
      pcall(self.RegisterEvent, self, ev)
    end
  elseif e == "GOSSIP_SHOW" then gossip()
  elseif e == "QUEST_GREETING" then greeting()
  elseif e == "QUEST_DETAIL" then
    if on("autoQuest") and not paused() and canTake(questID()) and AcceptQuest then AcceptQuest() end
  elseif e == "QUEST_PROGRESS" then
    if on("autoQuest") and not paused() and GUIDE[questID()] and IsQuestCompletable and IsQuestCompletable() and CompleteQuest then CompleteQuest() end
  elseif e == "QUEST_COMPLETE" then
    if on("autoQuest") and not paused() and GUIDE[questID()] and GetNumQuestChoices and GetNumQuestChoices() <= 1 and GetQuestReward then
      GetQuestReward(GetNumQuestChoices() == 1 and 1 or nil)
    end
  elseif e == "MERCHANT_SHOW" then
    if paused() then return end
    if on("autoJunk") and C_Container and C_Container.GetContainerNumSlots then
      local total = 0
      for bag = 0, 4 do
        for slot = 1, C_Container.GetContainerNumSlots(bag) or 0 do
          local info = C_Container.GetContainerItemInfo(bag, slot)
          if info and info.quality == 0 and not info.hasNoValue then
            local price = select(11, GetItemInfo(info.hyperlink or info.itemID)) or 0
            total = total + price * (info.stackCount or 1)
            C_Container.UseContainerItem(bag, slot)
          end
        end
      end
      if total > 0 then say("sold junk for " .. GetCoinTextureString(total) .. ".") end
    end
    if on("autoRepair") and CanMerchantRepair and CanMerchantRepair() then
      local cost, need = GetRepairAllCost()
      if need and cost and cost > 0 and cost <= GetMoney() then RepairAllItems(); say("repaired for " .. GetCoinTextureString(cost) .. ".") end
    end
  end
end)
